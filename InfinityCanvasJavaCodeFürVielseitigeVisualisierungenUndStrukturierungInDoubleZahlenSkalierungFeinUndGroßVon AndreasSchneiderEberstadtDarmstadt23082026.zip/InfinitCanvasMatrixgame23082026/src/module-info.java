/**
 * 
 */
/**
 * 
 */
module InfinitCanvasMatrixgame23082026 {
	requires java.desktop;
}