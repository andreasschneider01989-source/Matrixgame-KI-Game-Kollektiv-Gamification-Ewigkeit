package ordner1;

import java.awt.Color;
import java.util.ArrayList;

public class Unit {
	// --- BASIS & ENTROPIE ---
	public double basisEntroDouble;
	public double[] basisentros = new double[100];

	// --- PHYSIKALISCHE GRÖSSEN ---
	public double x, y, z;
	public double vx, vy, vz;
	public double ax, ay, az;
	public double mass;
	public int radius;
	
	public double maxSpeed=5*Math.random();

	public double EKin;
	public double Ex, Ey, Ez;
	public double time = 255.0;
	double pe4;

	// --- FARBEN & ZUSTAND ---
	public double rot, green, blue;
	public Color color;
	public boolean movable = true;
	public boolean leben = true;

	// --- SIMULATIONS-STEUERUNG (NEU) ---
	// Standardmäßig alles auf false, damit das Objekt ruhig ist
	public boolean updatePositionAktiv = false;
	public boolean entropieMoveAktiv = false;
	public String algorithmus = "HALTEN";
	// Ich finde es hier erst einmal allgemein gut den Wert als double ohne public
	// oder privat zu definieren oder zu setzen mit 0 im default und sichtbar und
	// änderbar in package
	double entropieMoveSpeed2ProCent;

	// --- KONSTRUKTOREN ---
	public Unit(double x, double y, double z, double vx, double vy, double vz, double mass, int radius, Color color) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.vx = vx;
		this.vy = vy;
		this.vz = vz;
		this.mass = mass;
		this.radius = radius;
		setColorSafe(color);
	}

	public Unit() {
		this(0, 0, 0, 0, 0, 0, 10, 10, Color.CYAN);
	}

	private void setColorSafe(Color c) {
		this.color = c != null ? c : Color.WHITE;
		this.rot = this.color.getRed();
		this.green = this.color.getGreen();
		this.blue = this.color.getBlue();
	}

	// --- DYNAMISCHER ZUGRIFF ---
	public double getVariable(String name) {
		switch (name.toLowerCase()) {
		case "x":
			return x;
		case "y":
			return y;
		case "z":
			return z;
		case "vx":
			return vx;
		case "vy":
			return vy;
		case "vz":
			return vz;
		case "mass":
		case "masse":
			return mass;
		case "radius":
			return radius;
		case "ekin":
			return EKin;
		case "time":
			return time;
		default:
			return 0.0;
		}
	}

	public void setVariable(String name, double wert) {
		switch (name.toLowerCase()) {
		case "x":
			x = wert;
			break;
		case "y":
			y = wert;
			break;
		case "z":
			z = wert;
			break;
		case "vx":
			vx = wert;
			break;
		case "vy":
			vy = wert;
			break;
		case "vz":
			vz = wert;
			break;
		case "mass":
		case "masse":
			mass = wert;
			break;
		case "radius":
			radius = (int) wert;
			break;
		case "ekin":
			EKin = wert;
			break;
		case "time":
			time = wert;
			break;
		}
	}

	// --- DIE ZENTRALE UPDATE-METHODE ---
	// Wird einmal pro Zeitschritt vom Canvas aufgerufen
	public void update() {

		if (entropieMoveSpeed2ProCent > (Math.random() * 100)) {
			entropieMoveSpeed2();
		}

		// 1. Entropie-Bewegung (wenn aktiviert)
		if (entropieMoveAktiv) {
			entropieMove();
		}

		// 2. Positions-Update (wenn aktiviert)
		if (updatePositionAktiv) {
			updatePosition(1.0); // 1.0 als Standard-Zeitschritt-Faktor
		}
		
		// 
//		if(randEntropie2ProCent>(Math.random() * 100)) {
//			randEntro();
//		}

		// Hier können später weitere Updates folgen, z.B.:
		// if (gravitationAktiv) { ... }
		// if (colorUpdateAktiv) { updateColor(); }
	}

	// --- DIE EINZELNEN VERHALTENSMETHODEN ---

	public void updatePosition(double timeStep) {
		this.x += (this.vx * timeStep);
		this.y += (this.vy * timeStep);
		this.z += (this.vz * timeStep);
	}

	public void entropieMove() {
		int rand = (int) (Math.random() * 8);
		if (rand < 2)
			return;
		if (rand == 2)
			x++;
		if (rand == 3)
			x--;
		if (rand == 4)
			y++;
		if (rand == 5)
			y--;
		if (rand == 6)
			z++;
		if (rand == 7)
			z--;
	}

	public void entropieMoveSpeed2() {
		// Bewege dich in jede Richtung per Random * Geschwindigkeit
		x = x + vx * Math.random();
		y = y + vy * Math.random();
		z = z + vz * Math.random();
	}

	public void entropieMoveSpeed() {
		// Bewege dich in jede Richtung per Random * Geschwindigkeit
		x = x + vx * Math.random() + Math.random() - Math.random();
		y = y + vy * Math.random() + Math.random() - Math.random();
		z = z + vz * Math.random() + Math.random() - Math.random();
	}

	public void entropieMoveSpeedPyt() {
		// Bewege dich in jede Richtung per Random * Geschwindigkeit
		// vx^2+vy^2+vz^2 <= Geschwindigkeit^2
		// später weiter

		x = x + vx * Math.pow(Math.random(), 0.5);
		y = y + vy * Math.random();
		z = z + vz * Math.random();
	}

	// allgemein für zwei doubles
	void randEntro() {

	}

	public void randEntropie3(Unit other) {

//		if (Math.random() > 0.01) {
//			double x = Math.random() * this.x;
//			this.x = this.x + other.x * Math.random();
//			other.x = other.x + x;
//		}
		if (Math.random() > 0.0001) {
			double y1 = Math.random() * this.y;
			double y2=other.y * Math.random();
			this.y = this.y + y2;
			other.y = other.y + y1;
			this.y=this.y-y1;
			other.y=other.y-y2;
		}
		if (Math.random() > 0.0001) {
			double x1 = Math.random() * this.x;
			double x2=other.x * Math.random();
			this.x = this.x + x2;
			other.x = other.x + x1;
			this.x=this.x-x1;
			other.x=other.x-x2;
		}
		
		if (Math.random() > 0.00001) {
			double z1 = Math.random() * this.z;
			double z2=other.z * Math.random();
			this.z = this.z - z1;
			other.z = other.z + z2;
			this.z=this.z+z1;
			
			other.z=other.z-z2;
		}
		
		

		// Das mit allen Variablen der Unit

	}
	
	public void randEntropie4(Unit other) {

//		if (Math.random() > 0.01) {
//			double x = Math.random() * this.x;
//			this.x = this.x + other.x * Math.random();
//			other.x = other.x + x;
//		}
			double x1 = Math.random() * (other.x-this.x);
			double y1 = Math.random() * (other.y-this.y);
			double z1 = Math.random() * (other.z-this.z);
			while(x1*x1+y1*y1+z1*z1>this.maxSpeed*this.maxSpeed/Math.random()*Math.random()) {if(Math.random()>0.5)return;x1*=Math.random();y1*=Math.random();z1*=Math.random();}
			if (Math.random() >pe4) {
		
			this.vx = this.vx +x1;
			other.vx = other.vx - x1;
			this.x+=x1;
			other.x-=x1;
			
		
		
		if (Math.random() > pe4) {
			
		
			this.vy = this.vy +y1;
			other.vy = other.vy - y1;
			this.y+=y1;
			other.y-=y1;
			
		
		
		if (Math.random() > pe4) {
		
		
			this.vz = this.vz +z1;
			this.z+=z1;
			other.vz = other.vz - z1;
			other.z-=z1;
			
		}}}
//		if (Math.random() > 0.0001) {
//			double x1 = Math.random() * this.x;
//			double x2=other.x * Math.random();
//			this.x = this.x + x2;
//			other.x = other.x + x1;
//			this.x=this.x-x1;
//			other.x=other.x-x2;
//		}
//		
//		if (Math.random() > 0.00001) {
//			double z1 = Math.random() * this.z;
//			double z2=other.z * Math.random();
//			this.z = this.z - z1;
//			other.z = other.z + z2;
//			this.z=this.z+z1;
//			
//			other.z=other.z-z2;
		}
	
	public void randEntropie2(Unit other) {

		if (Math.random() > 0.1) {
			if(this.x<other.x) {this.vx+=Math.random();other.vx-=Math.random();}
			if(this.y<other.y) {this.vy+=Math.random();other.vy-=Math.random();}
			if(this.z<other.z) {this.vz+=Math.random();other.vz-=Math.random();}
		
		
		}}

	// (Die restlichen Methoden wie gravity, angleichen etc. bleiben hier
	// unverändert erhalten)
}
