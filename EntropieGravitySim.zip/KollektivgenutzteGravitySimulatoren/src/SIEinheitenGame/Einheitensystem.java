package SIEinheitenGame;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Kernmodul für das SI-Einheiten Wahrscheinlichkeits-Quiz (Matrixgame Modul).
 * Verwaltet SI-Basiseinheiten, abgeleitete Einheiten und generiert dynamisch
 * Zuordnungsaufgaben sowie dimensionshomogene, algebraisch umgestellte Gleichungen.
 */
public class Einheitensystem {

    // --- Innere Klassen zur Modellierung komplexer Fakten ---

    /** Definiert eine primäre Ableitungsformel (Zielgröße = Komponenten). Z.B. Druck = Kraft * Fläche^-1. */
    private static class Derivation {
        public final String resultQuantityName; 
        public final String resultSymbol;       
        public final Map<String, Integer> componentQuantities; // Größen-Name -> Exponent

        public Derivation(String resultName, String resultSym, Map<String, Integer> components) {
            this.resultQuantityName = resultName;
            this.resultSymbol = resultSym;
            this.componentQuantities = components;
        }
    }

    /** Repräsentiert eine algebraisch umgestellte Gleichung: LinkeSeite = RechteSeite. */
    private static class Equation {
        public final Map<String, Integer> leftSide;
        public final Map<String, Integer> rightSide;

        public Equation(Map<String, Integer> leftSide, Map<String, Integer> rightSide) {
            this.leftSide = leftSide;
            this.rightSide = rightSide;
        }
    }
    
    // --- Konstanten und Datenstrukturen ---
    private static final int Q_SYMBOL = 0;    
    private static final int U_SYMBOL = 1;    
    private static final int U_NAME = 2;      
    private static final int DIM_FORMULA = 3; 

    // Alle bekannten Größen, ihre Symbole, Namen und Dimensionsformeln (in Basis-Einheiten)
    private static final Map<String, String[]> ALLE_EINHEITEN_FAKTEN = new HashMap<>();
    // Die Basis-Ableitungen (z.B. F = m*a) zur Generierung neuer Gleichungen
    private static final List<Derivation> ALLE_ABLEITUNGEN = new ArrayList<>(); 

    private final Random random = new Random();

    // --- Statischer Initialisierungsblock ---
    static {
        // Basisgrößen
        ALLE_EINHEITEN_FAKTEN.put("Zeit", new String[]{"t", "s", "Sekunde", "s"});
        ALLE_EINHEITEN_FAKTEN.put("Länge (Strecke)", new String[]{"l", "m", "Meter", "m"});
        ALLE_EINHEITEN_FAKTEN.put("Masse", new String[]{"m", "kg", "Kilogramm", "kg"});
        ALLE_EINHEITEN_FAKTEN.put("Elektrische Stromstärke", new String[]{"I", "A", "Ampere", "A"});
        ALLE_EINHEITEN_FAKTEN.put("Thermodynamische Temperatur", new String[]{"T", "K", "Kelvin", "K"});
        ALLE_EINHEITEN_FAKTEN.put("Stoffmenge", new String[]{"n", "mol", "Mol", "mol"});
        ALLE_EINHEITEN_FAKTEN.put("Lichtstärke", new String[]{"Iv", "cd", "Candela", "cd"});

        // Abgeleitete Einheiten
        ALLE_EINHEITEN_FAKTEN.put("Frequenz", new String[]{"f", "Hz", "Hertz", "s^-1"});
        ALLE_EINHEITEN_FAKTEN.put("Kraft", new String[]{"F", "N", "Newton", "kg*m*s^-2"});
        ALLE_EINHEITEN_FAKTEN.put("Druck", new String[]{"p", "Pa", "Pascal", "kg*m^-1*s^-2"});
        ALLE_EINHEITEN_FAKTEN.put("Energie, Arbeit, Wärme", new String[]{"E", "J", "Joule", "kg*m^2*s^-2"});
        ALLE_EINHEITEN_FAKTEN.put("Leistung", new String[]{"P", "W", "Watt", "kg*m^2*s^-3"});
        ALLE_EINHEITEN_FAKTEN.put("elektrische Ladung", new String[]{"Q", "C", "Coulomb", "A*s"});
        ALLE_EINHEITEN_FAKTEN.put("elektrische Spannung", new String[]{"U", "V", "Volt", "kg*m^2*s^-3*A^-1"});
        ALLE_EINHEITEN_FAKTEN.put("elektrischer Widerstand", new String[]{"R", "Ω", "Ohm", "kg*m^2*s^-3*A^-2"});
        ALLE_EINHEITEN_FAKTEN.put("elektrischer Leitwert", new String[]{"G", "S", "Siemens", "kg^-1*m^-2*s^3*A^2"});
        ALLE_EINHEITEN_FAKTEN.put("magnetischer Fluss", new String[]{"Φ", "Wb", "Weber", "kg*m^2*s^-2*A^-1"});
        ALLE_EINHEITEN_FAKTEN.put("Energiedosis", new String[]{"D", "Gy", "Gray", "m^2*s^-2"});
        ALLE_EINHEITEN_FAKTEN.put("Fläche", new String[]{"A", "m^2", "Quadratmeter", "m^2"});
        ALLE_EINHEITEN_FAKTEN.put("Volumen", new String[]{"V", "m^3", "Kubikmeter", "m^3"});
        ALLE_EINHEITEN_FAKTEN.put("Geschwindigkeit", new String[]{"v", "m/s", "Meter pro Sekunde", "m*s^-1"});
        ALLE_EINHEITEN_FAKTEN.put("Beschleunigung", new String[]{"a", "m/s^2", "Meter pro Sekunde Quadrat", "m*s^-2"});
        ALLE_EINHEITEN_FAKTEN.put("Dichte", new String[]{"ρ", "kg/m^3", "Kilogramm pro Kubikmeter", "kg*m^-3"});
        ALLE_EINHEITEN_FAKTEN.put("Volumenflussrate", new String[]{"Qv", "m^3/s", "Kubikmeter pro Sekunde", "m^3*s^-1"});


        // --- NEU: Basis-Ableitungen für algebraische Generierung ---
        ALLE_ABLEITUNGEN.add(new Derivation("Volumen", "V", Map.of("Länge (Strecke)", 3)));
        ALLE_ABLEITUNGEN.add(new Derivation("Beschleunigung", "a", Map.of("Länge (Strecke)", 1, "Zeit", -2)));
        ALLE_ABLEITUNGEN.add(new Derivation("Dichte", "ρ", Map.of("Masse", 1, "Volumen", -1))); // Dichte = Masse/Volumen
        ALLE_ABLEITUNGEN.add(new Derivation("Kraft", "N", Map.of("Masse", 1, "Beschleunigung", 1))); 
        ALLE_ABLEITUNGEN.add(new Derivation("Druck", "Pa", Map.of("Kraft", 1, "Fläche", -1)));
        ALLE_ABLEITUNGEN.add(new Derivation("Energie, Arbeit, Wärme", "J", Map.of("Kraft", 1, "Länge (Strecke)", 1)));
        ALLE_ABLEITUNGEN.add(new Derivation("Leistung", "W", Map.of("Energie, Arbeit, Wärme", 1, "Zeit", -1)));
        ALLE_ABLEITUNGEN.add(new Derivation("elektrische Spannung", "V", Map.of("Leistung", 1, "Elektrische Stromstärke", -1)));
    }
    
    // --- Hilfsmethoden für die Dimensionsanalyse ---
    
    /**
     * Zerlegt eine Dimensionsformel (z.B. "kg*m^2*s^-2") in eine Map: Basis-Einheit -> Exponent.
     */
     private Map<String, Integer> parseDimensionFormula(String formula) {
        Map<String, Integer> dimensions = new HashMap<>();
        if (formula == null || formula.isEmpty() || formula.equals("1")) return dimensions;

        // Ersetze / durch * und ändere Exponenten zu negativ (vereinfacht das Parsen)
        String tempFormula = formula.replaceAll("([a-zA-ZΩμρΦ]+)/([a-zA-ZΩμρΦ]+)", "$1*$2^-1");

        Pattern pattern = Pattern.compile("([a-zA-ZΩμρΦ]+)(\\^[-+]?\\d+)?");
        Matcher matcher = pattern.matcher(tempFormula);

        while (matcher.find()) {
            String unit = matcher.group(1);
            String exponentPart = matcher.group(2);
            int exponent = 1;

            if (exponentPart != null && exponentPart.length() > 1) {
                try {
                    exponent = Integer.parseInt(exponentPart.substring(1)); // Entferne das '^'
                } catch (NumberFormatException ignored) {}
            }
            dimensions.put(unit, dimensions.getOrDefault(unit, 0) + exponent);
        }
        return dimensions;
    }

    /**
     * Berechnet die kombinierten Basis-Dimensionen für eine Seite der Gleichung 
     * (durch Auflösen aller enthaltenen Größen in ihre Basis-Einheiten).
     */
    private Map<String, Integer> getCombinedDimensions(Map<String, Integer> quantityMap) {
        Map<String, Integer> combinedDimensions = new HashMap<>();
        
        for (Map.Entry<String, Integer> entry : quantityMap.entrySet()) {
            String quantityName = entry.getKey();
            int quantityExponent = entry.getValue();

            // Hole die Dimensionsformel der Größe (z.B. "Kraft" -> "kg*m*s^-2")
            if (!ALLE_EINHEITEN_FAKTEN.containsKey(quantityName)) continue;
            
            String dimFormula = ALLE_EINHEITEN_FAKTEN.get(quantityName)[DIM_FORMULA];
            Map<String, Integer> componentDimensions = parseDimensionFormula(dimFormula);
            
            // Füge die Dimensionen hinzu (Basis-Einheit * Exponent der Größe)
            for (Map.Entry<String, Integer> dimEntry : componentDimensions.entrySet()) {
                String baseUnit = dimEntry.getKey();
                int baseExponent = dimEntry.getValue();
                
                int newExponent = combinedDimensions.getOrDefault(baseUnit, 0) + (baseExponent * quantityExponent);
                combinedDimensions.put(baseUnit, newExponent);
            }
        }
        return combinedDimensions;
    }

    /**
     * Prüft, ob die Dimensionen beider Seiten der Gleichung gleich sind (Dimensionshomogenität).
     */
    private boolean checkEquationConsistency(Equation equation) {
        Map<String, Integer> dimLeft = getCombinedDimensions(equation.leftSide);
        Map<String, Integer> dimRight = getCombinedDimensions(equation.rightSide);
        
        dimLeft.entrySet().removeIf(entry -> entry.getValue() == 0);
        dimRight.entrySet().removeIf(entry -> entry.getValue() == 0);

        return dimLeft.equals(dimRight);
    }

    // --- Methoden zur Generierung und Manipulation ---

    /**
     * Verschiebt einen zufällig gewählten Term von einer Seite zur anderen 
     * (d.h. invertiert den Exponenten). Wird zur algebraischen Umstellung genutzt.
     */
    private void moveTerm(Map<String, Integer> source, Map<String, Integer> target) {
        if (source.isEmpty()) return;

        List<String> keys = new ArrayList<>(source.keySet());
        String termToMove = keys.get(random.nextInt(keys.size()));
        
        int exponent = source.remove(termToMove);
        int invertedExponent = -exponent;

        // Füge zum Ziel hinzu und summiere, falls der Term bereits existiert
        target.merge(termToMove, invertedExponent, Integer::sum);
        
        // Entferne das Element, falls die Summe 0 ergibt (z.B. A * A^-1 = 1)
        target.entrySet().removeIf(entry -> entry.getValue() == 0);
    }

    /**
     * Erzeugt eine String-Repräsentation der Gleichungsseite (z.B. "Masse/Volumen").
     */
    private String formatEquationSide(Map<String, Integer> side) {
        StringBuilder numerator = new StringBuilder();
        StringBuilder denominator = new StringBuilder();

        // Sortierung für konsistenteren Output (optional)
        List<String> sortedKeys = new ArrayList<>(side.keySet());
        Collections.sort(sortedKeys); 

        for (String quantityName : sortedKeys) {
            int exponent = side.get(quantityName);
            if (exponent == 0) continue;
            
            String symbol = ALLE_EINHEITEN_FAKTEN.get(quantityName)[Q_SYMBOL]; 
            
            String term = symbol;
            if (Math.abs(exponent) != 1) {
                term += "^" + Math.abs(exponent);
            }

            if (exponent > 0) {
                if (numerator.length() > 0) numerator.append("*");
                numerator.append(term);
            } else { // exponent < 0
                if (denominator.length() > 0) denominator.append("*");
                denominator.append(term);
            }
        }
        
        if (denominator.length() == 0) {
            return numerator.toString().isEmpty() ? "1" : numerator.toString();
        } else {
            String result = numerator.toString();
            if (result.isEmpty()) result = "1";
            return result + "/" + denominator.toString();
        }
    }

    /**
     * Generiert eine algebraisch umgestellte Gleichung basierend auf einer wahren Ableitung.
     */
    private Equation generateAlgebraicEquation(Derivation baseDerivation) {
        Map<String, Integer> left = new HashMap<>();
        Map<String, Integer> right = new HashMap<>();

        // Starte mit der Basis-Ableitung: Zielgröße (links) = Komponenten (rechts)
        left.put(baseDerivation.resultQuantityName, 1);
        right.putAll(baseDerivation.componentQuantities);

        // Führe zufällige algebraische Umstellungen durch (bis zu 2 Schritte)
        int steps = random.nextInt(3); 

        for (int i = 0; i < steps; i++) {
            // Wähle die Seite, von der verschoben wird (zufällig links oder rechts)
            boolean moveRightToLeft = random.nextBoolean();

            if (moveRightToLeft && !right.isEmpty()) {
                moveTerm(right, left);
            } else if (!left.isEmpty()) {
                moveTerm(left, right);
            }
        }
        
        return new Equation(left, right);
    }

    /**
     * Erzeugt eine zufällig manipulierte Dimensionsformel, die NICHT korrekt ist.
     */
    private String generateFalseDimensionStatement(String correctFormula) {
        Map<String, Integer> correctDimensions = parseDimensionFormula(correctFormula);
        List<String> units = new ArrayList<>(correctDimensions.keySet());

        if (units.isEmpty()) {
            return "m*s"; 
        }

        String unitToManipulate = units.get(random.nextInt(units.size()));
        int originalExponent = correctDimensions.get(unitToManipulate);
        
        int manipulatedExponent = originalExponent + (random.nextBoolean() ? 1 : -1);
        if (manipulatedExponent == 0) { 
            manipulatedExponent = originalExponent + (originalExponent == 0 ? 1 : 2); 
        }

        Map<String, Integer> falseDimensions = new HashMap<>(correctDimensions);
        falseDimensions.put(unitToManipulate, manipulatedExponent);

        // Rekonstruktion der falschen Formel
        StringBuilder sb = new StringBuilder();
        List<String> sortedUnits = new ArrayList<>(falseDimensions.keySet());
        Collections.sort(sortedUnits); 
        
        for (String unit : sortedUnits) {
            int exponent = falseDimensions.getOrDefault(unit, 0);
            if (exponent != 0) {
                if (sb.length() > 0) sb.append("*");
                sb.append(unit);
                if (exponent != 1) {
                    sb.append("^").append(exponent);
                }
            }
        }
        
        return sb.toString();
    }
    
    /**
     * Generiert eine einfache Zuordnungs- oder Dimensionsgleichheitsaussage (die alte Logik).
     */
    private String[] generateSimpleStatement(boolean isTrue) {
        List<String> quantityNames = new ArrayList<>(ALLE_EINHEITEN_FAKTEN.keySet());
        String nameA = quantityNames.get(random.nextInt(quantityNames.size()));
        String[] factsA = ALLE_EINHEITEN_FAKTEN.get(nameA);

        int sourceIndex = random.nextInt(4);
        int targetIndex;
        do {
            targetIndex = random.nextInt(4);
        } while (targetIndex == sourceIndex);
        
        String sourceValue = factsA[sourceIndex];
        String correctTargetValue = factsA[targetIndex];

        if (sourceValue == null || correctTargetValue == null || sourceValue.isEmpty() || correctTargetValue.isEmpty()) {
            return generateSimpleStatement(isTrue); 
        }

        String targetValue;
        String statement;
        
        if (isTrue) {
            targetValue = correctTargetValue;
        } else {
            if (targetIndex == DIM_FORMULA) {
                targetValue = generateFalseDimensionStatement(correctTargetValue);
            } else {
                String nameB;
                do {
                    nameB = quantityNames.get(random.nextInt(quantityNames.size()));
                } while (nameB.equals(nameA) || ALLE_EINHEITEN_FAKTEN.get(nameB)[targetIndex].equals(correctTargetValue)); 
                targetValue = ALLE_EINHEITEN_FAKTEN.get(nameB)[targetIndex];
            }
        }
        
        // Formuliere die Aussage
        if (targetIndex == DIM_FORMULA || sourceIndex == DIM_FORMULA) {
             if(factsA[DIM_FORMULA].equals("1")) {
                 targetValue = (isTrue) ? "1" : (random.nextBoolean() ? "m*s" : "kg");
                 statement = "Die Größe '" + nameA + "' ist dimensionslos und dimensionsgleich zu **" + targetValue + "**.";
             } else {
                 statement = "Die Einheit '" + factsA[U_SYMBOL] + "' ist dimensionsgleich zu **" + targetValue + "**.";
             }

        } else {
            String sourceName;
            if (sourceIndex == Q_SYMBOL) sourceName = "Größensymbol";
            else if (sourceIndex == U_SYMBOL) sourceName = "Einheitensymbol";
            else sourceName = "Größen-/Einheitenname";

            String targetName;
            if (targetIndex == Q_SYMBOL) targetName = "Größensymbol";
            else if (targetIndex == U_SYMBOL) targetName = "Einheitensymbol";
            else targetName = "Einheitenname";

            statement = "Das " + sourceName + " **" + sourceValue + "** (für " + nameA + ") korrespondiert mit dem " + targetName + " **" + targetValue + "**.";
        }

        return new String[] {statement, isTrue ? "Wahr" : "Falsch"};
    }

    // --- Haupt-Generierungsmethode ---

    public String[] generateStatement(boolean isTrue) {
        // 80% Wahrscheinlichkeit für die komplexen, algebraischen Gleichungen
        if (random.nextDouble() < 0.8 && !ALLE_ABLEITUNGEN.isEmpty()) {
            
            Derivation baseDerivation = ALLE_ABLEITUNGEN.get(random.nextInt(ALLE_ABLEITUNGEN.size()));
            
            // 1. Erzeuge eine algebraisch umgestellte, wahre Gleichung
            Equation trueEquation = generateAlgebraicEquation(baseDerivation);
            
            String leftSideStr = formatEquationSide(trueEquation.leftSide);
            String rightSideStr = formatEquationSide(trueEquation.rightSide);
            
            if (isTrue) {
                // Wahre Aussage: Linke Seite = Rechte Seite
                 String statement = "Die Gleichung **" + leftSideStr + "** entspricht **" + rightSideStr + "**.";
                 return new String[] {statement, "Wahr"};
            } else {
                // Falsche Aussage: Manipuliere eine der Seiten
                
                // Wähle die Seite zur Manipulation (mit 50% Wahrscheinlichkeit)
                boolean manipulateLeft = random.nextBoolean();
                
                Map<String, Integer> sideToManipulate = manipulateLeft ? trueEquation.leftSide : trueEquation.rightSide;
                
                // Manipuliere einen Exponenten, um die Dimensionsgleichheit zu brechen
                Map<String, Integer> falseSide = new HashMap<>(sideToManipulate);
                
                // Wähle eine Größe zum Manipulieren
                if (falseSide.isEmpty()) return generateStatement(false);
                
                List<String> keys = new ArrayList<>(falseSide.keySet());
                String termToManipulate = keys.get(random.nextInt(keys.size()));
                
                // Ändere den Exponenten
                int originalExp = falseSide.get(termToManipulate);
                int newExp = originalExp + (random.nextBoolean() ? 1 : -1);
                if (newExp == 0 && originalExp != 0) newExp = originalExp + 2; 
                if (newExp == originalExp) newExp += (random.nextBoolean() ? 1 : -1);

                falseSide.put(termToManipulate, newExp);
                
                String falseSideStr = formatEquationSide(falseSide);

                String statement;
                if (manipulateLeft) {
                    statement = "Die Gleichung **" + falseSideStr + "** entspricht **" + rightSideStr + "**.";
                } else {
                    statement = "Die Gleichung **" + leftSideStr + "** entspricht **" + falseSideStr + "**.";
                }
                
                // Letzter Check: Wenn die Manipulation das Ergebnis nicht ändert, wiederholen.
                if (falseSideStr.equals(leftSideStr) || falseSideStr.equals(rightSideStr)) {
                    return generateStatement(false);
                }

                return new String[] {statement, "Falsch"};
            }
            
        } else {
            // 20% Fallback zur einfachen Logik
            return generateSimpleStatement(isTrue); 
        }
    }
}