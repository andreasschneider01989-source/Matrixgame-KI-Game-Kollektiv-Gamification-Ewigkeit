package SIEinheitenGame;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Arrays; // Neu hinzugefügt für Arrays-Nutzung in Einheitensystem

/**
 * Das KI-Game zur Bewertung der Wahrscheinlichkeit von Aussagen über SI-Einheiten.
 * Dies ist der didaktische Teil des Matrixgame-Projekts.
 */
public class SIEinheitenQuiz {

    private final Einheitensystem system = new Einheitensystem();
    private final Random random = new Random();
    private int level = 1;
    private int score = 0;
    private int roundsPlayed = 0;

    public static void main(String[] args) {
        System.out.println("Willkommen beim SI-Einheiten Wahrscheinlichkeits-Quiz (Matrixgame Modul)!");
        System.out.println("Basiert auf den SI-Basiseinheiten und abgeleiteten Einheiten.");
        System.out.println("Ihre Aufgabe: Schätzen Sie die Wahrscheinlichkeit (in %) ein, mit der die Aussage WAHR ist.");
        
        SIEinheitenQuiz game = new SIEinheitenQuiz();
        game.startGame();
    }

    public void startGame() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            roundsPlayed++;
            System.out.println("\n--- Runde " + roundsPlayed + " | Level: " + level + " | Score: " + score + " ---");
            
            // Wähle zufällig, ob eine wahre oder falsche Aussage generiert werden soll
            // Starte mit 50/50. 
            boolean isTrue = random.nextBoolean(); 
            String[] statementData = system.generateStatement(isTrue);
            String statement = statementData[0];
            String actualResult = statementData[1];
            
            System.out.println("Aussage (P_wahr = ?): " + statement);
            
            double userProbability = getUserInput(scanner);
            
            evaluateAnswer(userProbability, actualResult);
            
            if (roundsPlayed % 5 == 0) {
                levelUpCheck();
            }
            
            System.out.println("Weiter? (j/n)");
            if (scanner.nextLine().trim().equalsIgnoreCase("n")) {
                break;
            }
        }
        System.out.println("\nSpiel beendet. Endstand: Level " + level + ", Score " + score);
        scanner.close();
    }

    private double getUserInput(Scanner scanner) {
        double prob = -1.0;
        while (prob < 0 || prob > 100) {
            System.out.print("Ihre geschätzte Wahrscheinlichkeit (0 - 100%): ");
            try {
                String input = scanner.nextLine().replace(",", ".");
                prob = Double.parseDouble(input);
                if (prob < 0 || prob > 100) {
                    System.out.println("Bitte geben Sie einen Wert zwischen 0 und 100 ein.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Ungültige Eingabe. Bitte eine Zahl eingeben.");
            }
        }
        return prob / 100.0; // Normalisiere auf 0 bis 1
    }

    private void evaluateAnswer(double userProb, String actualResult) {
        boolean actualTruth = actualResult.equals("Wahr");
        double actualProb = actualTruth ? 1.0 : 0.0;
        
        // Berechnung des Scores (Brier-Score-Logik)
        double difference = userProb - actualProb;
        int points = (int) Math.round(100 * (1.0 - difference * difference));
        
        System.out.println("-> Die Aussage war: **" + actualResult + "** (" + (actualTruth ? "100%" : "0%") + " Wahrscheinlichkeit)");
        System.out.println("Ihre Schätzung: " + String.format("%.0f%%", userProb * 100));
        System.out.println("Punkte erhalten: " + points);
        
        score += points;
    }
    
    private void levelUpCheck() {
        int requiredScoreForLevelUp = 5 * 90; // 450 Punkte pro 5 Runden
        int newLevel = (score / requiredScoreForLevelUp) + 1;
        
        if (newLevel > level) {
            level = newLevel;
            System.out.println("\n🎉 **LEVEL UP!** 🎉 Sie sind jetzt Level " + level + "!");
            // Einbettung des Matrixgame-Entwicklungsziels (wie gewünscht)
            System.out.println("> Fokus-Hinweis (Matrixgame-Entwicklungsziel): Um Ihren 'negativen Perfektionismus' und die 'Angst vor Misserfolgen' zu bearbeiten, erinnern Sie sich: Es ist didaktisch wertvoll, nicht immer 100% zu tippen, sondern die Wahrscheinlichkeit präzise abzubilden. Die Abweichung ist der Lernprozess!");
        }
    }
}