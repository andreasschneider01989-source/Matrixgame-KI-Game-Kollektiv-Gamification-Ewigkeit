package SIEinheitenGame;

// Repräsentiert eine physikalische Gleichung der Form:
// Zielgröße = QuelleA * QuelleB / QuelleC...
public class Derivation {
    public final String resultQuantityName; // Z.B. "Druck"
    public final String resultSymbol;       // Z.B. "Pa"

    // Die Ableitung selbst, bestehend aus Größen-Namen und ihren Exponenten
    // Z.B. für Druck (Pa = N/m²): { "Kraft": 1, "Länge (Strecke)": -2 }
    public final java.util.Map<String, Integer> componentQuantities; 

    public Derivation(String resultName, String resultSym, java.util.Map<String, Integer> components) {
        this.resultQuantityName = resultName;
        this.resultSymbol = resultSym;
        this.componentQuantities = components;
    }
}