package BasisEditorenMatrixgame2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class SchöneButtonLeiste extends JPanel implements MouseListener {

// --- Simulationskonstanten ---
	int FRAME_WIDTH = 1920;
	int FRAME_HEIGHT = 1080;

// --- Zoom-Variablen ---
	private double zoomFactor = 1.0;
	double zoomCenterX = 0;
	double zoomCenterY = 0;
	static final double ZOOM_STEP = 1.2;
	double feinheit = 70;
	double PAN_STEP = feinheit * zoomFactor;

	public static ArrayList<MasseKugel> bodies = new ArrayList<>();
	
	String[] buttonNames = new String[10];

	
	double[] buttonValues1=new double[10];
	
	
	String[] buttonValues=new String[10];
	

// --- Konstruktor ---

	public SchöneButtonLeiste() {
		setPreferredSize(new Dimension(FRAME_WIDTH, FRAME_HEIGHT));
		setBackground(Color.BLACK);
		addMouseListener(this); // <<< EINZIGE notwendige Aktivierung
		
		
		buttonValues1[0]=1.0;
		buttonValues1[1]=1.0;
		buttonValues1[2]=1.0;
		buttonValues1[3]=1.0;
		buttonValues1[4]=1.0;
		buttonValues1[5]=1.0;
		buttonValues1[6]=1.0;
		buttonValues1[7]=1.0;
		buttonValues1[8]=1.0;
		buttonValues1[9]=1.0;
		
		buttonValues[0]=buttonValues1[0]+"";
		buttonValues[1]=buttonValues1[1]+"";
		buttonValues[2]=buttonValues1[2]+"";
		buttonValues[3]=buttonValues1[3]+"";
		buttonValues[4]=buttonValues1[4]+"";
		buttonValues[5]=buttonValues1[5]+"";
		buttonValues[6]=buttonValues1[6]+"";
		buttonValues[7]=buttonValues1[7]+"";
		buttonValues[8]=buttonValues1[8]+"";
		buttonValues[9]=buttonValues1[9]+"";
		
		buttonNames[0]="BodyNumber";
		buttonNames[1]="PosX";
		buttonNames[2]="PosY";
		buttonNames[3]="PosZ";
		buttonNames[4]="VX";
		buttonNames[5]="VY";
		buttonNames[6]="VZ";
		buttonNames[7]="AX";
		buttonNames[8]="AY";
		buttonNames[9]="AZ";
	}

// --- Pan-Methoden ---

	public void panLeft() { zoomCenterX += PAN_STEP; repaint(); }
	public void panRight() { zoomCenterX -= PAN_STEP; repaint(); }
	public void panUp() { zoomCenterY += PAN_STEP; repaint(); }
	public void panDown() { zoomCenterY -= PAN_STEP; repaint(); }

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		for (MasseKugel body : bodies) {
			double radius = body.radius * zoomFactor;
			Color color = body.color;
			double posX = body.x;
			double posY = body.y;
			// Berücksichtige Pan und Zoom bei der Positionierung
			double sx = (zoomCenterX + posX) * zoomFactor + getWidth() / 2.0;
			double sy = (zoomCenterY + posY) * zoomFactor + getHeight() / 2.0;
			g2.setColor(color);
			g2.fillOval((int) (sx - radius), (int) (sy - radius), (int) (radius * 2), (int) (radius * 2));
		}
		
		// Gitter für neue Buttons
		
		for(int i=0; i<buttonZahl; i++) {
			g2.setColor(new Color(0,0,255));
			g2.drawRect((int)buttonPosX, (int)buttonHohe*i, (int)buttonBreite, 80);
			g2.drawString(buttonNames[i], (int)buttonPosX, (int)buttonHohe*i+20);
			g2.drawString(buttonValues[i], (int)buttonPosX, (int)buttonHohe*i+40);		
		}
	}

// --- MouseListener ---
double buttonPosX=1400;
double buttonBreite=100.0;
double buttonHohe=80;
int buttonOptionen=5;
int buttonZahl=10;
	@Override
	public void mousePressed(MouseEvent e) {
		for(int i=0; i<10; i++) {
		if(e.getX()>=buttonPosX && e.getX()<buttonPosX+buttonBreite/buttonOptionen && e.getY()<80*i+80&&e.getY()>80*i) {buttonValues1[i]=0; buttonValues[i]=buttonValues1[i]+""; repaint();}
		if(e.getX()>=buttonPosX+buttonBreite/buttonOptionen*1 && e.getX()<buttonPosX+buttonBreite/buttonOptionen*2 && e.getY()<80*i+80&&e.getY()>80*i) {buttonValues1[i]++; buttonValues[i]=buttonValues1[i]+""; repaint();}
		if(e.getX()>=buttonPosX+buttonBreite/buttonOptionen*2 && e.getX()<buttonPosX+buttonBreite/buttonOptionen*3 && e.getY()<80*i+80&&e.getY()>80*i) {buttonValues1[i]*=2.0; buttonValues[i]=buttonValues1[i]+""; repaint();}
		if(e.getX()>=buttonPosX+buttonBreite/buttonOptionen*3 && e.getX()<buttonPosX+buttonBreite/buttonOptionen*4 && e.getY()<80*i+80&&e.getY()>80*i) {buttonValues1[i]--; buttonValues[i]=buttonValues1[i]+""; repaint();}
		if(e.getX()>=buttonPosX+buttonBreite/buttonOptionen*4 && e.getX()<buttonPosX+buttonBreite/buttonOptionen*5 && e.getY()<80*i+80&&e.getY()>80*i) {buttonValues1[i]/=2.0; buttonValues[i]=buttonValues1[i]+""; repaint();}}
		}
	


	// Ungenutzte Impementierungen
	@Override public void mouseReleased(MouseEvent e) {}
	@Override public void mouseEntered(MouseEvent e) {}
	@Override public void mouseExited(MouseEvent e) {}
	@Override public void mouseClicked(MouseEvent e) {
	
	}

// --- Zoom ---

	public void zoomIn() {
		zoomFactor *= ZOOM_STEP;
		PAN_STEP = feinheit / zoomFactor;
		repaint();
	}

	public void zoomOut() {
		zoomFactor /= ZOOM_STEP;
		PAN_STEP = feinheit / zoomFactor;
		repaint();
	}

// --- main (unverändert) ---

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			JFrame frame = new JFrame("N-Body Sonnensystem-Simulation (QDBV-Modul)");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			SchöneButtonLeiste simPanel = new SchöneButtonLeiste();
			frame.setLayout(new BorderLayout());
			frame.add(simPanel, BorderLayout.CENTER);

			JButton zoomIn = new JButton("Zoom In");
			JButton zoomOut = new JButton("Zoom Out");
			JButton speedUp = new JButton("Speed Up");
			JButton speedDown = new JButton("Speed Down");
			JButton panLeft = new JButton("← Links");
			JButton panRight = new JButton("Rechts →");
			JButton panUp = new JButton("↑ Hoch");
			JButton panDown = new JButton("↓ Runter");

			zoomIn.addActionListener(e -> simPanel.zoomIn());
			zoomOut.addActionListener(e -> simPanel.zoomOut());
			panLeft.addActionListener(e -> simPanel.panLeft());
			panRight.addActionListener(e -> simPanel.panRight());
			panUp.addActionListener(e -> simPanel.panUp());
			panDown.addActionListener(e -> simPanel.panDown());

			JPanel control = new JPanel();
			control.add(zoomIn);
			control.add(zoomOut);
			control.add(speedUp);
			control.add(speedDown);
			control.add(panLeft);
			control.add(panRight);
			control.add(panUp);
			control.add(panDown);

			frame.add(control, BorderLayout.NORTH);
			frame.setSize(1920, 1080);
			frame.setLocationRelativeTo(null);
			frame.setVisible(true);

			bodies.add(new MasseKugel(5, 5, 5, 5, 5, 5, 5, 5, Color.RED));
			bodies.add(new MasseKugel(50, 5, 5, 5, 5, 5, 5, 5, Color.RED));
			bodies.add(new MasseKugel(5, 50, 5, 5, 5, 5, 5, 5, Color.RED));
		});
	}


}
