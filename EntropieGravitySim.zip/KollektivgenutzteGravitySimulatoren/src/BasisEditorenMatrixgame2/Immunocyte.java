package BasisEditorenMatrixgame2;

public class Immunocyte extends LivingEntity {
    public Immunocyte() {
        super();
        this.lifeForce = 10 + Math.random() * 20;
        this.maxLifeForce = lifeForce;
        this.immunityLevel = 0.1; // neugeborenes Immunsystem – lernt erst
        this.memoryMarkers = new long[16];
        this.size = 8 + Math.random() * 12;
        this.speed = 300 + Math.random() * 400;
    }

    @Override
    public void updateBehavior(List<LivingEntity> allEntities) {
        LivingEntity nearestThreat = findNearestNonSelf(allEntities);
        if (nearestThreat != null) {
            if (!isSelf(nearestThreat)) {
                moveTo(nearestThreat);
                if (getDistance(nearestThreat) < distance) {
                    attack(nearestThreat);
                    learnFrom(nearestThreat); // Gedächtniszelle wird stärker
                }
            }
        } else {
            patrol(); // ruhige Erkundung = kindliche Neugier
        }
    }

    private void learnFrom(LivingEntity pathogen) {
        immunityLevel = Math.min(1.0, immunityLevel + 0.02);
        // hier später echtes maschinelles Lernen oder einfaches Hashing des RGB-Musters
    }
}