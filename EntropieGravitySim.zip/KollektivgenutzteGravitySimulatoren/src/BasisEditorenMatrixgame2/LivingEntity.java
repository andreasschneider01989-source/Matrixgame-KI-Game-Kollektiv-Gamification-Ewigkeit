package BasisEditorenMatrixgame2;

// Neue abstrakte Basisklasse für alles Lebendige im Matrixgame
public abstract class LivingEntity extends KreisObjekt {
    double lifeForce;           // aktuelle "Leben"-Energie (kann > maxLeben sein bei Heilung)
    double maxLifeForce;
    double immunityLevel;       // 0.0 bis 1.0 – wie gut erkennt sie Selbst/Nicht-Selbst?
    long[] memoryMarkers;       // Gedächtnis für bereits gesehene Antigene (z.B. RGB-Hashes)
    boolean isRegulatory = false; // T-reg Zelle? Unterdrückt Überreaktionen?

    public boolean isSelf(LivingEntity other) {
        // Fraktales Selbst-Erkennungsprinzip: je ähnlicher die "Seelenfarbe", desto mehr Selbst
        double colorDiff = colordif(other);
        double selfThreshold = 80.0 * (1.0 - immunityLevel); // Reife Immunsystem = engere Toleranz
        return colorDiff < selfThreshold;
    }

    public void signalCytokineStorm() {
        // später: beeinflusst alle Einheiten im Radius → Angst vor Überreaktion = Perfektionismus
    }
}

