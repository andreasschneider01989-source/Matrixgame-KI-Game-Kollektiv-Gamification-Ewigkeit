package BasisEditorenMatrixgame2;

public class KreisObjekt {
  double size;
  double red;
  double green;
  double blue;
  
  double posX;
  double posY;
  double posZ;
  
  double vx;
  double vy;
  double vz;
  
  public KreisObjekt(double size, double red, double green, double blue, double posX, double posY, double posZ,double vx, double vy, double vz) {
		this.size = size;
		this.red = red;
		this.green = green;
		this.blue = blue;
		this.posX = posX;
		this.posY = posY;
		this.posZ = posZ;
		this.vx = vx;
		this.vy = vy;
		this.vz = vz;
	}
  
public KreisObjekt(double size, double red, double green, double blue, double posX, double posY, double posZ) {
	this.size = size;
	this.red = red;
	this.green = green;
	this.blue = blue;
	this.posX = posX;
	this.posY = posY;
	this.posZ = posZ;
}


public KreisObjekt(double posX, double posY) {
	this.posX = posX;
	this.posY = posY;
	this.size = 10.0;
	this.red = 255;
	this.green = 0;
	this.blue = 0;
	this.posZ = 0;
}

//Default mit interessantem Random (für die Initialisierung des Kindes)
public KreisObjekt () {
	// Standard-Initialisierung für Kinder/neue Einheiten
	this.size = 5000;
	this.red = 255 * Math.random();
	this.green = 255 * Math.random();
	this.blue = 255 * Math.random();
	this.posX = (Math.random() - 0.5) * 10000;
	this.posY = (Math.random() - 0.5) * 10000;
	this.posZ = 0;
	this.vx = 0;
	this.vy = 0;
	this.vz = 0;
}

public void move (double time) {
	posX=posX+vx*time;
	posY=posY+vy*time;
	posZ=posZ+vz*time;
}

/**
 * Berechnet die Farbdifferenz (Euklidische Distanz im RGB-Raum).
 */
public double colordif(KreisObjekt other) {
	double difR = red - other.red;
	double difG = green - other.green;
	double difB = blue - other.blue;
	
	// Pythagoras: d = sqrt(dR^2 + dG^2 + dB^2)
	double difQ = difR * difR + difG * difG + difB * difB;
	return Math.pow(difQ, 0.5);
}
  
}