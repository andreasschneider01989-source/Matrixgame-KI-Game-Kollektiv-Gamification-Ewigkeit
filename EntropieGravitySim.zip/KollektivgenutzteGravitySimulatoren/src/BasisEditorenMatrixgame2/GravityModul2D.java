package BasisEditorenMatrixgame2;

import javax.swing.*;

import p1.MasseKugel;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GravityModul2D extends JPanel implements MouseListener {

// --- Simulationskonstanten ---
	int FRAME_WIDTH = 1920;
	int FRAME_HEIGHT = 1080;

// --- Zoom-Variablen ---
	private double zoomFactor = 1.0;
	double zoomCenterX = 0;
	double zoomCenterY = 0;
	static final double ZOOM_STEP = 1.2;
	double feinheit = 70;
	double PAN_STEP = feinheit * zoomFactor;

	double time = 1.0;
	long pause = 100;

	String[] buttonNames = new String[10];

	double[] buttonValues1 = new double[10];

	String[] buttonValues = new String[10];

	ArrayList<MasseKugel> erschaffen = new ArrayList<MasseKugel>();
	ArrayList<MasseKugel> bausteine = new ArrayList<MasseKugel>();

	static double bausteinNumber = 0;
	
	double G=0.000001;
	double stepps=1;

// --- Konstruktor ---

	public GravityModul2D() {

		bausteine.add(new MasseKugel(0, 0, 0, 0, 0, 0, 1, 5, new Color(100, 0, 0)));
		bausteine.add(new MasseKugel(0, 0, 0, 0, 0, 0, 2, 5, new Color(0, 100, 0)));
		bausteine.add(new MasseKugel(0, 0, 0, 0, 0, 0, 3, 5, new Color(0, 0, 100)));

		setPreferredSize(new Dimension(FRAME_WIDTH, FRAME_HEIGHT));
		setBackground(Color.BLACK);
		addMouseListener(this); // <<< EINZIGE notwendige Aktivierung

		buttonValues1[0] = 0;
		buttonValues1[1] = 0;
		buttonValues1[2] = 0;
		buttonValues1[3] = 0;
		buttonValues1[4] = 0;
		buttonValues1[5] = 0;
		buttonValues1[6] = 0;
		buttonValues1[7] = 0;
		buttonValues1[8] = 0;
		buttonValues1[9] = 0;

		buttonValues[0] = buttonValues1[0] + "";
		buttonValues[1] = buttonValues1[1] + "";
		buttonValues[2] = buttonValues1[2] + "";
		buttonValues[3] = buttonValues1[3] + "";
		buttonValues[4] = buttonValues1[4] + "";
		buttonValues[5] = buttonValues1[5] + "";
		buttonValues[6] = buttonValues1[6] + "";
		buttonValues[7] = buttonValues1[7] + "";
		buttonValues[8] = buttonValues1[8] + "";
		buttonValues[9] = buttonValues1[9] + "";

		buttonNames[0] = "BodyNumber";
		buttonNames[1] = "PosX";
		buttonNames[2] = "PosY";
		buttonNames[3] = "PosZ";
		buttonNames[4] = "VX";
		buttonNames[5] = "VY";
		buttonNames[6] = "VZ";
		buttonNames[7] = "AX";
		buttonNames[8] = "AY";
		buttonNames[9] = "AZ";
	}

// --- Pan-Methoden ---

	public void panLeft() {
		zoomCenterX += PAN_STEP;
		repaint();
	}

	public void panRight() {
		zoomCenterX -= PAN_STEP;
		repaint();
	}

	public void panUp() {
		zoomCenterY += PAN_STEP;
		repaint();
	}

	public void panDown() {
		zoomCenterY -= PAN_STEP;
		repaint();
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		for (MasseKugel body : erschaffen) {
			double radius = body.radius * zoomFactor;
			radius=Math.max(1, radius);
			Color color = body.color;
			double posX = body.x;
			double posY = body.y;
			// Berücksichtige Pan und Zoom bei der Positionierung
			double sx = (zoomCenterX + posX) * zoomFactor + getWidth() / 2.0;
			double sy = (zoomCenterY + posY) * zoomFactor + getHeight() / 2.0;
			g2.setColor(color);
			g2.fillOval((int) (sx - radius), (int) (sy - radius), (int) (radius * 2), (int) (radius * 2));
		}

		// Gitter für neue Buttons

		for (int i = 0; i < buttonZahl; i++) {
			g2.setColor(new Color(0, 0, 255));
			g2.drawRect((int) buttonPosX, (int) buttonHohe * i, (int) buttonBreite, 80);
			g2.drawString(buttonNames[i], (int) buttonPosX, (int) buttonHohe * i + 20);
			g2.drawString(buttonValues[i], (int) buttonPosX, (int) buttonHohe * i + 40);
		}
	}

// --- MouseListener ---
	double buttonPosX = 1400;
	double buttonBreite = 100.0;
	double buttonHohe = 80;
	int buttonOptionen = 5;
	int buttonZahl = 10;

	@Override
	public void mousePressed(MouseEvent e) {
		for (int i = 0; i < buttonZahl; i++) {
			if (e.getX() >= buttonPosX && e.getX() < buttonPosX + buttonBreite / buttonOptionen
					&& e.getY() < 80 * i + 80 && e.getY() > 80 * i) {
				buttonValues1[i] = 0;
				buttonValues[i] = buttonValues1[i] + "";
				setValues();
				repaint();
			}
			if (e.getX() >= buttonPosX + buttonBreite / buttonOptionen * 1
					&& e.getX() < buttonPosX + buttonBreite / buttonOptionen * 2 && e.getY() < 80 * i + 80
					&& e.getY() > 80 * i) {
				buttonValues1[i]++;
				buttonValues[i] = buttonValues1[i] + "";
				setValues();
				repaint();
			}
			if (e.getX() >= buttonPosX + buttonBreite / buttonOptionen * 2
					&& e.getX() < buttonPosX + buttonBreite / buttonOptionen * 3 && e.getY() < 80 * i + 80
					&& e.getY() > 80 * i) {
				buttonValues1[i] *= 2.0;
				buttonValues[i] = buttonValues1[i] + "";
				setValues();
				repaint();
			}
			if (e.getX() >= buttonPosX + buttonBreite / buttonOptionen * 3
					&& e.getX() < buttonPosX + buttonBreite / buttonOptionen * 4 && e.getY() < 80 * i + 80
					&& e.getY() > 80 * i) {
				buttonValues1[i]--;
				buttonValues[i] = buttonValues1[i] + "";
				setValues();
				repaint();
			}
			if (e.getX() >= buttonPosX + buttonBreite / buttonOptionen * 4
					&& e.getX() < buttonPosX + buttonBreite / buttonOptionen * 5 && e.getY() < 80 * i + 80
					&& e.getY() > 80 * i) {
				buttonValues1[i] /= 2.0;
				buttonValues[i] = buttonValues1[i] + "";
				setValues();
				repaint();
			}
		}
	}

	public void setValues() {
		for (int i = 1; i < buttonZahl; i++) {
			
			if (i == 0)
				bausteinNumber = buttonValues1[0];
			if((int) buttonValues1[0]>=bausteine.size())continue;
			if (i == 1)
				bausteine.get((int) buttonValues1[0]).x = buttonValues1[1];
			if (i == 2)
				bausteine.get((int) buttonValues1[0]).y = buttonValues1[2];
			if (i == 3)
				bausteine.get((int) buttonValues1[0]).z = buttonValues1[3];
			if (i == 4)
				bausteine.get((int) buttonValues1[0]).vx = buttonValues1[4];
			if (i == 5)
				bausteine.get((int) buttonValues1[0]).vy = buttonValues1[5];
			if (i == 6)
				bausteine.get((int) buttonValues1[0]).vz = buttonValues1[6];
			if (i == 7)
				bausteine.get((int) buttonValues1[0]).ax = buttonValues1[7];
			if (i == 8)
				bausteine.get((int) buttonValues1[0]).ay = buttonValues1[8];
			if (i == 9)
				bausteine.get((int) buttonValues1[0]).az = buttonValues1[9];
		}
	}

	public void setButtonValues() {
		for (int i = 1; i < buttonZahl; i++) {
			if (i == 1)
				buttonValues1[i] = bausteine.get((int) buttonValues1[0]).x;
			if (i == 2)
				buttonValues1[i] = bausteine.get((int) buttonValues1[0]).y;
			if (i == 3)
				buttonValues1[i] = bausteine.get((int) buttonValues1[0]).z;
			if (i == 4)
				buttonValues1[i] = bausteine.get((int) buttonValues1[0]).vx;
			if (i == 5)
				buttonValues1[i] = bausteine.get((int) buttonValues1[0]).vy;
			if (i == 6)
				buttonValues1[i] = bausteine.get((int) buttonValues1[0]).vz;
			if (i == 7)
				buttonValues1[i] = bausteine.get((int) buttonValues1[0]).ax;
			if (i == 8)
				buttonValues1[i] = bausteine.get((int) buttonValues1[0]).ay;
			if (i == 9)
				buttonValues1[i] = bausteine.get((int) buttonValues1[0]).az;
		}
	}

	// Ungenutzte Impementierungen
	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

// --- Zoom ---

	public void zoomIn() {
		zoomFactor *= ZOOM_STEP;
		PAN_STEP = feinheit / zoomFactor;
		repaint();
	}

	public void zoomOut() {
		zoomFactor /= ZOOM_STEP;
		PAN_STEP = feinheit / zoomFactor;
		repaint();
	}

	public void generate() {
		if (bausteine.size() > (int) buttonValues1[0] && bausteine.get((int) buttonValues1[0]) != null) {

			MasseKugel current = bausteine.get((int) buttonValues1[0]);
			MasseKugel kopie = new MasseKugel(current.x, current.y, current.z, current.vx, current.vy, current.vz,
					current.mass, current.radius, current.color);
			kopie.ax = current.ax;
			kopie.ay = current.ay;
			kopie.az = current.az;
			kopie.rot = current.rot;
			kopie.green = current.green;
			kopie.blue = current.blue;
			erschaffen.add(kopie);
			repaint();
		}
	}
	
	public void bausteinUpgrade() {
		
	}

// --- main (unverändert) ---

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			JFrame frame = new JFrame("N-Body Sonnensystem-Simulation (QDBV-Modul)");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			GravityModul2D simPanel = new GravityModul2D();

			frame.setLayout(new BorderLayout());
			frame.add(simPanel, BorderLayout.CENTER);

			JButton zoomIn = new JButton("Zoom In");
			JButton zoomOut = new JButton("Zoom Out");
			JButton speedUp = new JButton("Speed Up");
			JButton speedDown = new JButton("Speed Down");
			JButton panLeft = new JButton("← Links");
			JButton panRight = new JButton("Rechts →");
			JButton panUp = new JButton("↑ Hoch");
			JButton panDown = new JButton("↓ Runter");
			JButton generate = new JButton("Generate");
			JButton play = new JButton("Play");

			zoomIn.addActionListener(e -> simPanel.zoomIn());
			zoomOut.addActionListener(e -> simPanel.zoomOut());
			panLeft.addActionListener(e -> simPanel.panLeft());
			panRight.addActionListener(e -> simPanel.panRight());
			panUp.addActionListener(e -> simPanel.panUp());
			panDown.addActionListener(e -> simPanel.panDown());
			generate.addActionListener(e -> simPanel.generate());
			play.addActionListener(e -> simPanel.play());

			JPanel control = new JPanel();
			control.add(zoomIn);
			control.add(zoomOut);
			control.add(speedUp);
			control.add(speedDown);
			control.add(panLeft);
			control.add(panRight);
			control.add(panUp);
			control.add(panDown);
			control.add(generate);
			control.add(play);

			frame.add(control, BorderLayout.NORTH);
			frame.setSize(1920, 1080);
			frame.setLocationRelativeTo(null);
			frame.setVisible(true);

//			simPanel.play(10);

		});
	}

	public void play() {

		int i = 0;
		while (i < buttonValues1[0]) {
			i++;
			timeStep(); // Berechnungen für den nächsten Zeitschritt

		}
		repaint();
	}

	public void timeStep() {
		GravityGemini();
		for (MasseKugel current : erschaffen) {
			current.updatePosition(time);
			current.updateV(time);
		}
	}
	
	public void GravityGemini() {
		for (int i2 = 0; i2 < stepps; i2++) {
			int n = erschaffen.size();
			double[] ax = new double[n];
			double[] ay = new double[n];
			double[] az = new double[n];
			for (int i = 0; i < n; i++) {
				MasseKugel bi = erschaffen.get(i);
				ax[i] = ay[i] = az[i] = 0;
				if (!bi.movable)
					continue;
				for (int j = 0; j < n; j++) {
					if (i == j)
						continue;
					MasseKugel bj = erschaffen.get(j);
					double dx = bj.x - bi.x;
					double dy = bj.y - bi.y;
					double dz = bj.z - bi.z;
					double r2 = dx * dx + dy * dy + dz * dz;
					double r = Math.sqrt(r2);
					if(r==0)continue;
					double a = G * bj.mass / r2;
					ax[i] += a * dx / r;
					ay[i] += a * dy / r;
					az[i] += a * dz / r;
				}
			}
			for (int i = 0; i < n; i++) {
				MasseKugel b = erschaffen.get(i);
				if (b.movable) {
					b.vx += ax[i];
					b.vy += ay[i];
					b.vz += az[i];
				}
				
			}
		}
		repaint();
	}

}
