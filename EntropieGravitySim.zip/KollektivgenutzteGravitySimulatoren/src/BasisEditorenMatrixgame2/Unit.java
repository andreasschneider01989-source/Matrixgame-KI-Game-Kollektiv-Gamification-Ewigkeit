package BasisEditorenMatrixgame2;

public class Unit extends KreisObjekt {
	double maxLeben;
	double leben;
	double damage;
	double distance;
	double speed;
	int team;
	int kills;
	public Unit target = null;

	public void moveTo(KreisObjekt oponent) {
		double distQ = (this.posX - oponent.posX) * (this.posX - oponent.posX)
				+ (this.posY - oponent.posY) * (this.posY - oponent.posY)
				+ (this.posZ - oponent.posZ) * (this.posZ - oponent.posZ);
		double dist = Math.pow(distQ, 0.5);
		
		double dx=posX-oponent.posX;
		double dy=posY-oponent.posY;
		double dz=posZ-oponent.posZ;
		
		double movDist=Math.min(speed, Math.abs(dist-distance));
		
		vx=-dx/dist*movDist;
		vy=-dy/dist*movDist;
		vz=-dz/dist*movDist;

	}
	
	public double getDistance(KreisObjekt oponent) {
		double distQ = (this.posX - oponent.posX) * (this.posX - oponent.posX)
				+ (this.posY - oponent.posY) * (this.posY - oponent.posY)
				+ (this.posZ - oponent.posZ) * (this.posZ - oponent.posZ);
		double dist = Math.pow(distQ, 0.5);
		return dist;
	}

	public Unit() {
		super();
		this.leben = 5*Math.random()/Math.random();
		this.maxLeben=leben;
		this.damage = Math.random()/Math.random();
		this.distance = 500*Math.random()/Math.random();
		this.speed = 500*Math.random()/Math.random();
		this.team = (int)(Math.random()*2);
//		this.größePerLive(1);
		this.größePerKills(1);
	}
	
	public void choseRandColorTeam() {
		if (Math.random() < 0.3)
			if (red + green + blue < 300)
				team = 1;
			else if (red + green + blue < 500)
			team = 2;
			else
				team = 1;
		if (Math.random() < 0.5) {
			if (red > green && green > blue)
				team=1;
		if (red < green && green < blue)
			team=3;}
		
		if (Math.random() < 0.3) {
			if (red > green || green > blue)
				team=1;
		if (red < green || green < blue)
			team=2;}
	}
	
	public void größePerLive(double div) {
		double size=Math.pow(leben/div, 0.3333);
		size=Math.min(size, 20);
		this.size=size;
	}
	
	public void größePerKills(double div) {
		double size=3+Math.pow(kills/div, 0.3333);
		size=Math.min(size, 20);
		this.size=size;
	}
	
	
}