package BasisEditorenMatrixgame2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SchönerZoom2FormScaleUnitsEvolution extends JPanel {

    // --- Instanzvariablen (NICHT static) ---
    private int FRAME_WIDTH = 1920;
    private int FRAME_HEIGHT = 1080;
    private double zoomFactor = 1.0;
    private double zoomCenterX = 0;
    private double zoomCenterY = 0;
    private static final double ZOOM_STEP = 1.2;
    private double feinheit = 70;
    
    // volatile für sichere Thread-Kommunikation
    private volatile double pause = 1000.0; // Startet sehr langsam, beschleunigen Sie mit "Time Fast"
    
    private double PAN_STEP;

    // --- Tracking-Variablen ---
    private volatile Unit selectedUnit = null; 
    private volatile boolean isFollowing = false; 
    
    // Wichtig: unitList als Instanzvariable
    private List<Unit> unitList = new ArrayList<>();

    // --- Konstruktor ---
    public SchönerZoom2FormScaleUnitsEvolution() {
        initializeSettings();
        initializeUnits();
        setupPanel();
    }

    private void initializeSettings() {
        PAN_STEP = feinheit * zoomFactor;
    }

    // KLEINERER WERT für eine übersichtlichere Start-Welt
    double size = 50000; 
    private void initializeUnits() {
        // Starteinheiten (2000 Einheiten insgesamt)
        for (int i = 0; i < 1000; i++) {
            
            Unit Unit1 = new Unit();
            Unit1.team = 1;
            Unit1.posX = (size * Math.random() - 0.5 * size);
            Unit1.posY = (size * Math.random() - 0.5 * size);
            Unit1.red = 255; Unit1.green = 0; Unit1.blue = 0; // Rot-Gruppe (Feind)

            Unit Unit2 = new Unit();
            Unit2.team = 2;
            Unit2.posX = (size * Math.random() - 0.5 * size);
            Unit2.posY = (size * Math.random() - 0.5 * size);
            Unit2.red = 0; Unit2.green = 0; Unit2.blue = 255; // Blau-Gruppe (Feind)

            unitList.add(Unit1);
            unitList.add(Unit2);
        }
    }

    private void setupPanel() {
        setPreferredSize(new Dimension(FRAME_WIDTH, FRAME_HEIGHT));
        setBackground(Color.BLACK);
        addMouseListener(new UnitClickListener());
    }

    // --- Game Loop ---
    public void startGameLoop() {
        Thread gameThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    Thread.sleep((long) pause);
                    updateGameState();
                    updateCamera(); 
                    repaint(); 
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        gameThread.setDaemon(true); 
        gameThread.start();
    }
    
    private void updateCamera() {
        if (isFollowing && selectedUnit != null) {
            zoomCenterX = -selectedUnit.posX;
            zoomCenterY = -selectedUnit.posY;
        }
    }

    // Feind-Erkennung basiert auf Farbdifferenz > 250
    public Unit nextGegner(Unit current) {
        Unit gegner = null; 
        double min = Double.MAX_VALUE;
        
        for (Unit unit : unitList) {
            // Nur wenn die Einheit nicht man selbst ist UND die Farbdifferenz groß genug ist (> 250)
            if (current != unit && current.getDistance(unit) < min && current.colordif(unit) > 250) {
                min = current.getDistance(unit);
                gegner = unit;
            }
        }
        return gegner;
    }

    private void updateGameState() {
        List<Unit> currentUnits;
        synchronized (unitList) {
            currentUnits = new ArrayList<>(unitList);
        }

        List<Unit> toRemove = new ArrayList<>(); 
        List<Unit> toAdd = new ArrayList<>();    

        for (Unit unit : currentUnits) {
            
            if (unit.target == null || unit.target.leben <= 0) {
                unit.target = nextGegner(unit); 
            }
            
            Unit gegner = unit.target;
            
            if (gegner != null) {
                if (unit.getDistance(gegner) <= unit.distance) {
                    // Angriff
                    gegner.leben = gegner.leben - unit.damage;
                    gegner.größePerLive(1);
                    
                    if (gegner.leben <= 0) {
                        
                        if (isFollowing && gegner == selectedUnit) {
                            selectedUnit = unit;
                        }
                        
                        toRemove.add(gegner); 
                        
                        // EVOLUTION & REPRODUKTION NACH KILL
                        if (Math.random() < 0.2) { 
                            Unit child = unit.reproduce();
                            toAdd.add(child); 
                        }
                    }
                } else {
                    // Bewegung
                    unit.moveTo(gegner);
                    unit.move(1);
                    unit.größePerLive(1);
                }
            }
        }

        // Synchronisiere Änderungen mit der Hauptliste
        synchronized (unitList) {
            unitList.removeAll(toRemove);
            unitList.addAll(toAdd);
        }

        // Verfolgung beenden, falls die verfolgte Einheit entfernt wurde 
        if (isFollowing && selectedUnit != null && selectedUnit.leben <= 0) {
            isFollowing = false;
            selectedUnit = null;
        }
    }

    // --- Steuerungsmethoden (unverändert) ---
    public void panLeft() { isFollowing = false; zoomCenterX += PAN_STEP; repaint(); }
    public void panRight() { isFollowing = false; zoomCenterX -= PAN_STEP; repaint(); }
    public void panUp() { isFollowing = false; zoomCenterY += PAN_STEP; repaint(); }
    public void panDown() { isFollowing = false; zoomCenterY -= PAN_STEP; repaint(); }
    public void zoomIn() { zoomFactor *= ZOOM_STEP; updatePanStep(); repaint(); }
    public void zoomOut() { zoomFactor /= ZOOM_STEP; updatePanStep(); repaint(); }
    public void timeFast() { pause /= ZOOM_STEP; if (pause < 1) pause = 1; }
    public void timeSlow() { pause *= ZOOM_STEP; }
    private void updatePanStep() { PAN_STEP = feinheit / zoomFactor; }
    // ------------------------------------------

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, getWidth(), getHeight());
        
        List<Unit> safeUnitList;
        synchronized (unitList) {
            safeUnitList = new ArrayList<>(unitList);
        }

        for (Unit current : safeUnitList) {
            
            // =========================================================
            // === KRITISCHE FEHLERBEHEBUNG: Radius muss skaliert werden ===
            // =========================================================
            double radius = Math.abs(current.size) * zoomFactor;
            
            // Mindestgröße, damit man beim Herauszoomen Einheiten als Punkte sieht
            if (radius < 1.0) radius = 1.0; 
            
            Color color = new Color(
                    (int) Math.max(0, Math.min(255, current.red)),
                    (int) Math.max(0, Math.min(255, current.green)),
                    (int) Math.max(0, Math.min(255, current.blue))
            );

            // Position wird skaliert
            double sx = (zoomCenterX + current.posX) * zoomFactor + getWidth() / 2.0;
            double sy = (zoomCenterY + current.posY) * zoomFactor + getHeight() / 2.0;

            g2.setColor(color);
            // Zeichnen mit skaliertem Radius
            g2.fillOval((int) (sx - radius), (int) (sy - radius),
                        (int) (radius * 2), (int) (radius * 2));
            
            // Hebe die ausgewählte Einheit hervor
            if (current == selectedUnit) {
                g2.setColor(Color.YELLOW);
                g2.drawOval((int) (sx - radius - 2), (int) (sy - radius - 2),
                            (int) (radius * 2 + 4), (int) (radius * 2 + 4));
            }
        }
    }
    
    // --- PRIVATE INNER CLASS: UNIT SELECTION HANDLER (unverändert) ---
    private class UnitClickListener extends MouseAdapter {
        @Override
        public void mousePressed(MouseEvent e) {
            
            synchronized (unitList) {
                for (int i = unitList.size() - 1; i >= 0; i--) {
                    Unit current = unitList.get(i);

                    double sx = (zoomCenterX + current.posX) * zoomFactor + getWidth() / 2.0;
                    double sy = (zoomCenterY + current.posY) * zoomFactor + getHeight() / 2.0;
                    
                    // Verwende den skalierten Radius für die Klickerkennung
                    double radius = Math.abs(current.size) * zoomFactor; 
                    if (radius < 1.0) radius = 1.0; 

                    double dx = e.getX() - sx;
                    double dy = e.getY() - sy;
                    double distance = Math.sqrt(dx * dx + dy * dy);

                    if (distance <= radius) {
                        if (current == selectedUnit) {
                            isFollowing = false;
                            selectedUnit = null;
                        } else {
                            selectedUnit = current;
                            isFollowing = true;
                        }
                        repaint();
                        return;
                    }
                }
            }
            
            if (isFollowing) {
                isFollowing = false;
                selectedUnit = null;
                repaint();
            }
        }
    }

    // --- MAIN METHODE (unverändert) ---
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            createAndShowGUI();
        });
    }

    private static void createAndShowGUI() {
        SchönerZoom2FormScaleUnitsEvolution simPanel = new SchönerZoom2FormScaleUnitsEvolution();
        JFrame frame = new JFrame("Evolutionäres RGB-Ökosystem (Matrixgame)");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.add(simPanel, BorderLayout.CENTER);
        frame.add(createControlPanel(simPanel), BorderLayout.NORTH);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        simPanel.startGameLoop();
    }

    private static JPanel createControlPanel(SchönerZoom2FormScaleUnitsEvolution simPanel) {
        JPanel control = new JPanel();

        JButton zoomIn = new JButton("Zoom In");
        JButton zoomOut = new JButton("Zoom Out");
        JButton panLeft = new JButton("← Links");
        JButton panRight = new JButton("Rechts →");
        JButton panUp = new JButton("↑ Hoch");
        JButton panDown = new JButton("↓ Runter");
        JButton timeSlow = new JButton("Time Slow");
        JButton timeFast = new JButton("Time Fast");

        zoomIn.addActionListener(e -> simPanel.zoomIn());
        zoomOut.addActionListener(e -> simPanel.zoomOut());
        panLeft.addActionListener(e -> simPanel.panLeft());
        panRight.addActionListener(e -> simPanel.panRight());
        panUp.addActionListener(e -> simPanel.panUp());
        panDown.addActionListener(e -> simPanel.panDown());
        timeSlow.addActionListener(e -> simPanel.timeSlow());
        timeFast.addActionListener(e -> simPanel.timeFast());

        control.add(zoomIn);
        control.add(zoomOut);
        control.add(panLeft);
        control.add(panRight);
        control.add(panUp);
        control.add(panDown);
        control.add(timeSlow);
        control.add(timeFast);

        return control;
    }
}