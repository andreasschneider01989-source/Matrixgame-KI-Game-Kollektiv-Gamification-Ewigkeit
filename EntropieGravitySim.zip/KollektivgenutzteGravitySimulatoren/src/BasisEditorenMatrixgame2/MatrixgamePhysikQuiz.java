package BasisEditorenMatrixgame2;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatrixgamePhysikQuiz {

    // Statische Datenbank für physikalische Größen und Einheiten
    private static final Map<String, String[]> ALLE_EINHEITEN_FAKTEN = new HashMap<>();
    private static final List<Derivation> ALLE_ABLEITUNGEN = new ArrayList<>();
    
    // Konstanten für die Indizes im String-Array
    private static final int Q_SYMBOL = 0;    // Größensymbol (z.B. l für Länge)
    private static final int U_SYMBOL = 1;    // Einheitensymbol (z.B. m für Meter)
    private static final int U_NAME = 2;      // Einheitenname (z.B. Meter)
    private static final int DIM_FORMULA = 3; // Dimensionsformel (Basis-Einheiten)
    
    // Innere Klasse für physikalische Ableitungen
    private static class Derivation {
        public final String resultQuantityName; 
        public final String resultSymbol;       
        public final Map<String, Integer> componentQuantities; 
        
        public Derivation(String resultName, String resultSym, Map<String, Integer> components) {
            this.resultQuantityName = resultName;
            this.resultSymbol = resultSym;
            this.componentQuantities = components;
        }
    }
    
    // Innere Klasse für algebraische Gleichungen
    private static class Equation {
        public final Map<String, Integer> leftSide;
        public final Map<String, Integer> rightSide;
        
        public Equation(Map<String, Integer> leftSide, Map<String, Integer> rightSide) {
            this.leftSide = leftSide;
            this.rightSide = rightSide;
        }
    }
    
    // Statische Initialisierung der physikalischen Daten
    static {
        // Basisgrößen
        ALLE_EINHEITEN_FAKTEN.put("Zeit", new String[]{"t", "s", "Sekunde", "s"});
        ALLE_EINHEITEN_FAKTEN.put("Länge (Strecke)", new String[]{"l", "m", "Meter", "m"});
        ALLE_EINHEITEN_FAKTEN.put("Masse", new String[]{"m", "kg", "Kilogramm", "kg"});
        ALLE_EINHEITEN_FAKTEN.put("Elektrische Stromstärke", new String[]{"I", "A", "Ampere", "A"});
        ALLE_EINHEITEN_FAKTEN.put("Thermodynamische Temperatur", new String[]{"T", "K", "Kelvin", "K"});
        ALLE_EINHEITEN_FAKTEN.put("Stoffmenge", new String[]{"n", "mol", "Mol", "mol"});
        ALLE_EINHEITEN_FAKTEN.put("Lichtstärke", new String[]{"Iv", "cd", "Candela", "cd"});
        
        // Abgeleitete Einheiten
        ALLE_EINHEITEN_FAKTEN.put("Frequenz", new String[]{"f", "Hz", "Hertz", "s^-1"});
        ALLE_EINHEITEN_FAKTEN.put("Kraft", new String[]{"F", "N", "Newton", "kg*m*s^-2"});
        ALLE_EINHEITEN_FAKTEN.put("Druck", new String[]{"p", "Pa", "Pascal", "kg*m^-1*s^-2"});
        ALLE_EINHEITEN_FAKTEN.put("Energie, Arbeit, Wärme", new String[]{"E", "J", "Joule", "kg*m^2*s^-2"});
        ALLE_EINHEITEN_FAKTEN.put("Leistung", new String[]{"P", "W", "Watt", "kg*m^2*s^-3"});
        ALLE_EINHEITEN_FAKTEN.put("elektrische Ladung", new String[]{"Q", "C", "Coulomb", "A*s"});
        ALLE_EINHEITEN_FAKTEN.put("elektrische Spannung", new String[]{"U", "V", "Volt", "kg*m^2*s^-3*A^-1"});
        ALLE_EINHEITEN_FAKTEN.put("elektrischer Widerstand", new String[]{"R", "Ω", "Ohm", "kg*m^2*s^-3*A^-2"});
        ALLE_EINHEITEN_FAKTEN.put("elektrischer Leitwert", new String[]{"G", "S", "Siemens", "kg^-1*m^-2*s^3*A^2"});
        ALLE_EINHEITEN_FAKTEN.put("magnetischer Fluss", new String[]{"Φ", "Wb", "Weber", "kg*m^2*s^-2*A^-1"});
        ALLE_EINHEITEN_FAKTEN.put("Energiedosis", new String[]{"D", "Gy", "Gray", "m^2*s^-2"});
        
        // Neu hinzugefügte abgeleitete Einheiten/Größen
        ALLE_EINHEITEN_FAKTEN.put("Fläche", new String[]{"A", "m^2", "Quadratmeter", "m^2"});
        ALLE_EINHEITEN_FAKTEN.put("Volumen", new String[]{"V", "m^3", "Kubikmeter", "m^3"});
        ALLE_EINHEITEN_FAKTEN.put("Geschwindigkeit", new String[]{"v", "m/s", "Meter pro Sekunde", "m*s^-1"});
        ALLE_EINHEITEN_FAKTEN.put("Beschleunigung", new String[]{"a", "m/s^2", "Meter pro Sekunde Quadrat", "m*s^-2"});
        ALLE_EINHEITEN_FAKTEN.put("Dichte", new String[]{"ρ", "kg/m^3", "Kilogramm pro Kubikmeter", "kg*m^-3"});
        ALLE_EINHEITEN_FAKTEN.put("Volumenflussrate", new String[]{"Qv", "m^3/s", "Kubikmeter pro Sekunde", "m^3*s^-1"});
        
        // Basis-Ableitungen für algebraische Generierung
        ALLE_ABLEITUNGEN.add(new Derivation("Volumen", "V", Map.of("Länge (Strecke)", 3)));
        ALLE_ABLEITUNGEN.add(new Derivation("Beschleunigung", "a", Map.of("Länge (Strecke)", 1, "Zeit", -2)));
        ALLE_ABLEITUNGEN.add(new Derivation("Dichte", "ρ", Map.of("Masse", 1, "Volumen", -1))); // Dichte = Masse/Volumen
        ALLE_ABLEITUNGEN.add(new Derivation("Kraft", "N", Map.of("Masse", 1, "Beschleunigung", 1))); 
        ALLE_ABLEITUNGEN.add(new Derivation("Druck", "Pa", Map.of("Kraft", 1, "Fläche", -1)));
        ALLE_ABLEITUNGEN.add(new Derivation("Energie, Arbeit, Wärme", "J", Map.of("Kraft", 1, "Länge (Strecke)", 1)));
        ALLE_ABLEITUNGEN.add(new Derivation("Leistung", "W", Map.of("Energie, Arbeit, Wärme", 1, "Zeit", -1)));
        ALLE_ABLEITUNGEN.add(new Derivation("elektrische Spannung", "V", Map.of("Leistung", 1, "Elektrische Stromstärke", -1)));
    }
    
    // Hilfsmethode zur Dimensionsanalyse
    private static Map<String, Integer> parseDimensionFormula(String formula) {
        Map<String, Integer> dimensions = new HashMap<>();
        if (formula == null || formula.isEmpty() || formula.equals("1")) return dimensions;
        
        String tempFormula = formula.replaceAll("([a-zA-ZΩμρΦ]+)/([a-zA-ZΩμρΦ]+)", "$1*$2^-1");
        Pattern pattern = Pattern.compile("([a-zA-ZΩμρΦ]+)(\\^[-+]?\\d+)?");
        Matcher matcher = pattern.matcher(tempFormula);
        
        while (matcher.find()) {
            String unit = matcher.group(1);
            String exponentPart = matcher.group(2);
            int exponent = 1;
            if (exponentPart != null && exponentPart.length() > 1) {
                try {
                    exponent = Integer.parseInt(exponentPart.substring(1));
                } catch (NumberFormatException ignored) {}
            }
            dimensions.put(unit, dimensions.getOrDefault(unit, 0) + exponent);
        }
        return dimensions;
    }
    
    // Methode zur Kombination von Dimensionen
    private static Map<String, Integer> getCombinedDimensions(Map<String, Integer> quantityMap) {
        Map<String, Integer> combinedDimensions = new HashMap<>();
        for (Map.Entry<String, Integer> entry : quantityMap.entrySet()) {
            String quantityName = entry.getKey();
            int quantityExponent = entry.getValue();
            
            if (!ALLE_EINHEITEN_FAKTEN.containsKey(quantityName)) continue;
            String dimFormula = ALLE_EINHEITEN_FAKTEN.get(quantityName)[DIM_FORMULA];
            Map<String, Integer> componentDimensions = parseDimensionFormula(dimFormula);
            
            for (Map.Entry<String, Integer> dimEntry : componentDimensions.entrySet()) {
                String baseUnit = dimEntry.getKey();
                int baseExponent = dimEntry.getValue();
                int newExponent = combinedDimensions.getOrDefault(baseUnit, 0) + (baseExponent * quantityExponent);
                combinedDimensions.put(baseUnit, newExponent);
            }
        }
        return combinedDimensions;
    }
    
    // Methode zur Überprüfung der Gleichungskonsistenz
    private static boolean checkEquationConsistency(Equation equation) {
        Map<String, Integer> dimLeft = getCombinedDimensions(equation.leftSide);
        Map<String, Integer> dimRight = getCombinedDimensions(equation.rightSide);
        
        dimLeft.entrySet().removeIf(entry -> entry.getValue() == 0);
        dimRight.entrySet().removeIf(entry -> entry.getValue() == 0);
        
        return dimLeft.equals(dimRight);
    }
    
    // Methode zur Umstellung von Gleichungen
    private static void moveTerm(Map<String, Integer> source, Map<String, Integer> target) {
        if (source.isEmpty()) return;
        
        List<String> keys = new ArrayList<>(source.keySet());
        String termToMove = keys.get(new Random().nextInt(keys.size()));
        int exponent = source.remove(termToMove);
        int invertedExponent = -exponent;
        
        target.merge(termToMove, invertedExponent, Integer::sum);
        target.entrySet().removeIf(entry -> entry.getValue() == 0);
    }
    
    // Formatierung der Gleichungsseite
    private static String formatEquationSide(Map<String, Integer> side) {
        StringBuilder numerator = new StringBuilder();
        StringBuilder denominator = new StringBuilder();
        
        List<String> sortedKeys = new ArrayList<>(side.keySet());
        Collections.sort(sortedKeys);
        
        for (String quantityName : sortedKeys) {
            int exponent = side.get(quantityName);
            if (exponent == 0) continue;
            
            String symbol = ALLE_EINHEITEN_FAKTEN.get(quantityName)[Q_SYMBOL]; 
            String term = symbol;
            
            if (Math.abs(exponent) != 1) {
                term += "^" + Math.abs(exponent);
            }
            
            if (exponent > 0) {
                if (numerator.length() > 0) numerator.append("*");
                numerator.append(term);
            } else {
                if (denominator.length() > 0) denominator.append("*");
                denominator.append(term);
            }
        }
        
        if (denominator.length() == 0) {
            return numerator.toString().isEmpty() ? "1" : numerator.toString();
        } else {
            String result = numerator.toString();
            if (result.isEmpty()) result = "1";
            return result + "/" + denominator.toString();
        }
    }
    
    // Generierung algebraischer Gleichungen
    private static Equation generateAlgebraicEquation(Derivation baseDerivation) {
        Map<String, Integer> left = new HashMap<>();
        Map<String, Integer> right = new HashMap<>();
        
        left.put(baseDerivation.resultQuantityName, 1);
        right.putAll(baseDerivation.componentQuantities);
        
        int steps = new Random().nextInt(3);
        for (int i = 0; i < steps; i++) {
            boolean moveRightToLeft = new Random().nextBoolean();
            if (moveRightToLeft && !right.isEmpty()) {
                moveTerm(right, left);
            } else if (!left.isEmpty()) {
                moveTerm(left, right);
            }
        }
        return new Equation(left, right);
    }
    
    // Generierung von Aussagen
    private static String[] generateStatement(boolean isTrue) {
        Random random = new Random();
        
        if (random.nextDouble() < 0.8 && !ALLE_ABLEITUNGEN.isEmpty()) {
            Derivation baseDerivation = ALLE_ABLEITUNGEN.get(random.nextInt(ALLE_ABLEITUNGEN.size()));
            Equation trueEquation = generateAlgebraicEquation(baseDerivation);
            
            String leftSideStr = formatEquationSide(trueEquation.leftSide);
            String rightSideStr = formatEquationSide(trueEquation.rightSide);
            
            if (isTrue) {
                String statement = "Die Gleichung **" + leftSideStr + "** entspricht **" + rightSideStr + "**.";
                return new String[] {statement, "Wahr"};
            } else {
                boolean manipulateLeft = random.nextBoolean();
                Map<String, Integer> sideToManipulate = manipulateLeft ? trueEquation.leftSide : trueEquation.rightSide;
                
                if (sideToManipulate.isEmpty()) return generateStatement(false);
                
                Map<String, Integer> falseSide = new HashMap<>(sideToManipulate);
                List<String> keys = new ArrayList<>(falseSide.keySet());
                String termToManipulate = keys.get(random.nextInt(keys.size()));
                
                int originalExp = falseSide.get(termToManipulate);
                int newExp = originalExp + (random.nextBoolean() ? 1 : -1);
                if (newExp == 0 && originalExp != 0) newExp = originalExp + 2;
                if (newExp == originalExp) newExp += (random.nextBoolean() ? 1 : -1);
                
                falseSide.put(termToManipulate, newExp);
                String falseSideStr = formatEquationSide(falseSide);
                
                String statement;
                if (manipulateLeft) {
                    statement = "Die Gleichung **" + falseSideStr + "** entspricht **" + rightSideStr + "**.";
                } else {
                    statement = "Die Gleichung **" + leftSideStr + "** entspricht **" + falseSideStr + "**.";
                }
                
                if (falseSideStr.equals(leftSideStr) || falseSideStr.equals(rightSideStr)) {
                    return generateStatement(false);
                }
                return new String[] {statement, "Falsch"};
            }
        } else {
            return generateSimpleStatement(isTrue);
        }
    }
    
    // Einfache Zuordnungsaussagen
    private static String[] generateSimpleStatement(boolean isTrue) {
        Random random = new Random();
        List<String> quantityNames = new ArrayList<>(ALLE_EINHEITEN_FAKTEN.keySet());
        
        String nameA = quantityNames.get(random.nextInt(quantityNames.size()));
        String[] factsA = ALLE_EINHEITEN_FAKTEN.get(nameA);
        
        int sourceIndex = random.nextInt(4);
        int targetIndex;
        do {
            targetIndex = random.nextInt(4);
        } while (targetIndex == sourceIndex);
        
        String sourceValue = factsA[sourceIndex];
        String correctTargetValue = factsA[targetIndex];
        
        if (sourceValue == null || correctTargetValue == null || sourceValue.isEmpty() || correctTargetValue.isEmpty()) {
            return generateSimpleStatement(isTrue); 
        }
        
        String targetValue;
        String statement;
        
        if (isTrue) {
            targetValue = correctTargetValue;
        } else {
            if (targetIndex == DIM_FORMULA) {
                targetValue = generateFalseDimensionStatement(correctTargetValue);
            } else {
                String nameB;
                do {
                    nameB = quantityNames.get(random.nextInt(quantityNames.size()));
                } while (nameB.equals(nameA) || ALLE_EINHEITEN_FAKTEN.get(nameB)[targetIndex].equals(correctTargetValue));
                targetValue = ALLE_EINHEITEN_FAKTEN.get(nameB)[targetIndex];
            }
        }
        
        if (targetIndex == DIM_FORMULA || sourceIndex == DIM_FORMULA) {
            if (factsA[DIM_FORMULA].equals("1")) {
                targetValue = (isTrue) ? "1" : (random.nextBoolean() ? "m*s" : "kg");
                statement = "Die Größe '" + nameA + "' ist dimensionslos und dimensionsgleich zu **" + targetValue + "**.";
            } else {
                statement = "Die Einheit '" + factsA[U_SYMBOL] + "' ist dimensionsgleich zu **" + targetValue + "**.";
            }
        } else {
            String sourceName;
            if (sourceIndex == Q_SYMBOL) sourceName = "Größensymbol";
            else if (sourceIndex == U_SYMBOL) sourceName = "Einheitensymbol";
            else sourceName = "Größen-/Einheitenname";
            
            String targetName;
            if (targetIndex == Q_SYMBOL) targetName = "Größensymbol";
            else if (targetIndex == U_SYMBOL) targetName = "Einheitensymbol";
            else targetName = "Einheitenname";
            
            statement = "Das " + sourceName + " **" + sourceValue + "** (für " + nameA + ") korrespondiert mit dem "