package BasisEditorenMatrixgame2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;
import java.util.List;

// Alle Klassen in einer Datei für sofortige Ausführung
public class SchönerZoom2FormScaleUnitsBasisFightImun extends JPanel {

    // --- Instanzvariablen ---
    private int FRAME_WIDTH = 1200; // Reduzierte Fenstergröße für bessere Darstellung
    private int FRAME_HEIGHT = 800;
    private double zoomFactor = 1.0;
    private double zoomCenterX = 0;
    private double zoomCenterY = 0;
    private static final double ZOOM_STEP = 1.2;
    private double feinheit = 70;
    private volatile double pause = 100.0; // Schnellere Startgeschwindigkeit
    private double PAN_STEP;
    
    // --- Tracking-Variablen ---
    private volatile Unit selectedUnit = null;
    private volatile boolean isFollowing = false;
    
    // Wichtige Listen
    private List<Unit> unitList = new ArrayList<>();
    private List<Unit> safeUnitList = new ArrayList<>(); // Thread-sichere Kopie

    // --- Konstruktor ---
    public SchönerZoom2FormScaleUnitsBasisFightImun() {
        initializeSettings();
        initializeUnits();
        setupPanel();
    }

    private void initializeSettings() {
        PAN_STEP = feinheit * zoomFactor;
    }

    double size = 1000000; // Reduzierte Weltgröße für bessere Übersicht

    private void initializeUnits() {
        // Erstelle verschiedene Arten von Einheiten (Zellen)
        Random rand = new Random();
        
        // T-Zellen (rote Einheiten)
        for (int i = 0; i < 2000; i++) {
            Unit tZelle = new Unit();
            tZelle.team = 1;
            tZelle.posX = (size * rand.nextDouble() - 0.5 * size);
            tZelle.posY = (size * rand.nextDouble() - 0.5 * size);
            tZelle.red = 255; tZelle.green = 50; tZelle.blue = 50; // Rot mit leichter Variation
            tZelle.leben = 100 + rand.nextDouble() * 50;
            tZelle.damage = 5 + rand.nextDouble() * 5;
            tZelle.speed = 2000 + rand.nextDouble() * 1000;
            unitList.add(tZelle);
        }
        
        // B-Zellen (blaue Einheiten)
        for (int i = 0; i < 2000; i++) {
            Unit bZelle = new Unit();
            bZelle.team = 2;
            bZelle.posX = (size * rand.nextDouble() - 0.5 * size);
            bZelle.posY = (size * rand.nextDouble() - 0.5 * size);
            bZelle.red = 50; bZelle.green = 50; bZelle.blue = 255; // Blau
            bZelle.leben = 80 + rand.nextDouble() * 40;
            bZelle.damage = 3 + rand.nextDouble() * 3;
            bZelle.speed = 1500 + rand.nextDouble() * 800;
            unitList.add(bZelle);
        }
        
        // Makrophagen (grüne Einheiten - große Fresszellen)
        for (int i = 0; i < 1000; i++) {
            Unit makrophage = new Unit();
            makrophage.team = 3;
            makrophage.posX = (size * rand.nextDouble() - 0.5 * size);
            makrophage.posY = (size * rand.nextDouble() - 0.5 * size);
            makrophage.red = 50; makrophage.green = 255; makrophage.blue = 50; // Grün
            makrophage.leben = 200 + rand.nextDouble() * 100;
            makrophage.damage = 8 + rand.nextDouble() * 4;
            makrophage.speed = 800 + rand.nextDouble() * 400;
            makrophage.size = 8000; // Größer dargestellt
            unitList.add(makrophage);
        }
        
        // Viren (lila Einheiten - Krankheitserreger)
        for (int i = 0; i < 3000; i++) {
            Unit virus = new Unit();
            virus.team = 4;
            virus.posX = (size * rand.nextDouble() - 0.5 * size);
            virus.posY = (size * rand.nextDouble() - 0.5 * size);
            virus.red = 200; virus.green = 50; virus.blue = 200; // Lila
            virus.leben = 30 + rand.nextDouble() * 20;
            virus.damage = 2 + rand.nextDouble() * 2;
            virus.speed = 3000 + rand.nextDouble() * 1500;
            virus.size = 3000; // Kleiner als Makrophagen
            unitList.add(virus);
        }
        
        // Zufällige Einheiten für Vielfalt
        for (int i = 0; i < 2000; i++) {
            Unit randomUnit = new Unit();
            randomUnit.team = 5 + (i % 3);
            randomUnit.posX = (size * rand.nextDouble() - 0.5 * size);
            randomUnit.posY = (size * rand.nextDouble() - 0.5 * size);
            randomUnit.red = 50 + rand.nextInt(200);
            randomUnit.green = 50 + rand.nextInt(200);
            randomUnit.blue = 50 + rand.nextInt(200);
            randomUnit.leben = 50 + rand.nextDouble() * 100;
            randomUnit.damage = 4 + rand.nextDouble() * 6;
            randomUnit.speed = 1000 + rand.nextDouble() * 2000;
            unitList.add(randomUnit);
        }
    }

    private void setupPanel() {
        setPreferredSize(new Dimension(FRAME_WIDTH, FRAME_HEIGHT));
        setBackground(Color.BLACK);
        addMouseListener(new UnitClickListener());
    }

    // --- Game Loop als Instanzmethode ---
    public void startGameLoop() {
        Thread gameThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    Thread.sleep((long) pause);
                    updateGameState();
                    updateCamera();
                    repaint();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        gameThread.setDaemon(true);
        gameThread.start();
    }

    private void updateCamera() {
        if (isFollowing && selectedUnit != null) {
            zoomCenterX = -selectedUnit.posX;
            zoomCenterY = -selectedUnit.posY;
        }
    }

    public Unit nextGegner(Unit current) {
        Unit gegner = null;
        double min = Double.MAX_VALUE;
        
        // Thread-sicheres Lesen der Liste
        synchronized (unitList) {
            for (Unit unit : unitList) {
                if (current != unit) {
                    double distance = current.getDistance(unit);
                    double colorDiff = current.colordif(unit);
                    
                    // Priorisiere nahe Gegner mit hoher Farbdifferenz
                    if (distance < min && colorDiff > 100 && current.team != unit.team) {
                        min = distance;
                        gegner = unit;
                    }
                }
            }
        }
        return gegner;
    }

    private void updateGameState() {
        List<Unit> toRemove = new ArrayList<>();
        List<Unit> toAdd = new ArrayList<>();
        
        // Thread-sicheres Lesen der Liste
        synchronized (unitList) {
            // Erstelle eine Kopie für die Verarbeitung
            List<Unit> currentUnits = new ArrayList<>(unitList);
            
            for (Unit unit : currentUnits) {
                // Suche neuen Gegner, wenn nötig
                if (unit.target == null || unit.target.leben <= 0 || Math.random() > 0.95) {
                    unit.target = nextGegner(unit);
                }
                
                Unit gegner = unit.target;
                if (gegner != null && gegner.leben > 0) {
                    if (unit.getDistance(gegner) <= unit.distance) {
                        // Angriff
                        gegner.leben -= unit.damage;
                        gegner.größePerLive(1);
                        
                        if (gegner.leben <= 0) {
                            // Rächer-Modus: Wenn die verfolgte Einheit stirbt, folge dem Killer
                            if (isFollowing && gegner == selectedUnit) {
                                selectedUnit = unit;
                            }
                            
                            toRemove.add(gegner);
                            
                            // 20% Chance auf Reproduktion nach Kill
                            if (Math.random() < 0.2) {
                                Unit child = reproduceUnit(unit);
                                toAdd.add(child);
                            }
                            
                            unit.kills++;
                            unit.leben = Math.min(unit.leben + 10, unit.maxLeben); // Belohnung für Kill
                        }
                    } else {
                        // Bewegung
                        unit.moveTo(gegner);
                        unit.move(1);
                        unit.größePerLive(1);
                    }
                }
            }
            
            // Entferne tote Einheiten und füge neue hinzu
            unitList.removeAll(toRemove);
            unitList.addAll(toAdd);
        }
        
        // Stopp die Verfolgung, wenn die Einheit tot ist
        if (isFollowing && selectedUnit != null && selectedUnit.leben <= 0) {
            isFollowing = false;
            selectedUnit = null;
        }
    }
    
    private Unit reproduceUnit(Unit parent) {
        Unit child = new Unit();
        Random rand = new Random();
        
        // Vererbe Eigenschaften mit Mutation
        child.red = parent.red * (0.9 + rand.nextDouble() * 0.2);
        child.green = parent.green * (0.9 + rand.nextDouble() * 0.2);
        child.blue = parent.blue * (0.9 + rand.nextDouble() * 0.2);
        
        // Begrenze Farbwerte
        child.red = Math.max(0, Math.min(255, child.red));
        child.green = Math.max(0, Math.min(255, child.green));
        child.blue = Math.max(0, Math.min(255, child.blue));
        
        // Vererbe Kampfparameter mit Mutation
        child.damage = parent.damage * (0.8 + rand.nextDouble() * 0.4);
        child.speed = parent.speed * (0.8 + rand.nextDouble() * 0.4);
        child.leben = parent.leben * 0.7;
        child.maxLeben = child.leben;
        
        // Position nahe der Eltern-Einheit
        child.posX = parent.posX + (rand.nextDouble() - 0.5) * 20000;
        child.posY = parent.posY + (rand.nextDouble() - 0.5) * 20000;
        
        child.team = parent.team;
        child.größePerLive(1);
        
        return child;
    }

    // --- Steuerungsmethoden ---
    public void panLeft() { isFollowing = false; zoomCenterX += PAN_STEP; repaint(); }
    public void panRight() { isFollowing = false; zoomCenterX -= PAN_STEP; repaint(); }
    public void panUp() { isFollowing = false; zoomCenterY += PAN_STEP; repaint(); }
    public void panDown() { isFollowing = false; zoomCenterY -= PAN_STEP; repaint(); }
    
    public void zoomIn() { zoomFactor *= ZOOM_STEP; updatePanStep(); repaint(); }
    public void zoomOut() { zoomFactor /= ZOOM_STEP; updatePanStep(); repaint(); }
    
    public void timeFast() { pause /= ZOOM_STEP; if (pause < 1) pause = 1; }
    public void timeSlow() { pause *= ZOOM_STEP; }
    
    private void updatePanStep() {
        PAN_STEP = feinheit / zoomFactor;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, getWidth(), getHeight());
        
        // Thread-sicheres Zeichnen
        synchronized (unitList) {
            safeUnitList = new ArrayList<>(unitList);
        }
        
        for (Unit current : safeUnitList) {
            // Radius wird skaliert für bessere Darstellung
            double radius = Math.abs(current.size) * zoomFactor;
            if (radius < 1.0) radius = 1.0; // Mindestgröße
            
            // Sicherstellen, dass Farbwerte gültig sind
            Color color = new Color(
                (int) Math.max(0, Math.min(255, current.red)),
                (int) Math.max(0, Math.min(255, current.green)),
                (int) Math.max(0, Math.min(255, current.blue))
            );
            
            // Positionskalkulation
            double sx = (zoomCenterX + current.posX) * zoomFactor + getWidth() / 2.0;
            double sy = (zoomCenterY + current.posY) * zoomFactor + getHeight() / 2.0;
            
            // Zeichne die Einheit
            g2.setColor(color);
            g2.fillOval((int) (sx - radius), (int) (sy - radius),
                       (int) (radius * 2), (int) (radius * 2));
            
            // Hebe die ausgewählte Einheit hervor
            if (current == selectedUnit) {
                g2.setColor(Color.YELLOW);
                g2.drawOval((int) (sx - radius - 2), (int) (sy - radius - 2),
                           (int) (radius * 2 + 4), (int) (radius * 2 + 4));
            }
        }
    }

    // --- Maus-Listener für Einheitenauswahl ---
    private class UnitClickListener extends MouseAdapter {
        @Override
        public void mousePressed(MouseEvent e) {
            synchronized (unitList) {
                // Iteriere rückwärts für "oberste" Einheit
                for (int i = unitList.size() - 1; i >= 0; i--) {
                    Unit current = unitList.get(i);
                    
                    double sx = (zoomCenterX + current.posX) * zoomFactor + getWidth() / 2.0;
                    double sy = (zoomCenterY + current.posY) * zoomFactor + getHeight() / 2.0;
                    double radius = Math.abs(current.size) * zoomFactor;
                    if (radius < 1.0) radius = 1.0;
                    
                    double dx = e.getX() - sx;
                    double dy = e.getY() - sy;
                    double distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance <= radius) {
                        if (current == selectedUnit) {
                            isFollowing = false;
                            selectedUnit = null;
                        } else {
                            selectedUnit = current;
                            isFollowing = true;
                        }
                        repaint();
                        return;
                    }
                }
            }
            
            // Keine Einheit getroffen - stoppe Tracking
            if (isFollowing) {
                isFollowing = false;
                selectedUnit = null;
                repaint();
            }
        }
    }

    // --- MAIN METHODE ---
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            createAndShowGUI();
        });
    }

    private static void createAndShowGUI() {
        // Erstelle das Simulationspanel
        SchönerZoom2FormScaleUnitsBasisFightImun simPanel = new SchönerZoom2FormScaleUnitsBasisFightImun();
        
        // Konfiguriere den Frame
        JFrame frame = new JFrame("Immunsystem-Simulation (Matrixgame)");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.add(simPanel, BorderLayout.CENTER);
        frame.add(createControlPanel(simPanel), BorderLayout.NORTH);
        
        // Anzeige
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        // Starte den Game Loop
        simPanel.startGameLoop();
    }

    private static JPanel createControlPanel(SchönerZoom2FormScaleUnitsBasisFightImun simPanel) {
        JPanel control = new JPanel();
        
        // Steuerelemente
        JButton zoomIn = new JButton("Zoom In (+)");
        JButton zoomOut = new JButton("Zoom Out (-)");
        JButton panLeft = new JButton("← Links");
        JButton panRight = new JButton("Rechts →");
        JButton panUp = new JButton("↑ Hoch");
        JButton panDown = new JButton("↓ Runter");
        JButton timeSlow = new JButton("Time Slow");
        JButton timeFast = new JButton("Time Fast");
        
        // Action Listeners
        zoomIn.addActionListener(e -> simPanel.zoomIn());
        zoomOut.addActionListener(e -> simPanel.zoomOut());
        panLeft.addActionListener(e -> simPanel.panLeft());
        panRight.addActionListener(e -> simPanel.panRight());
        panUp.addActionListener(e -> simPanel.panUp());
        panDown.addActionListener(e -> simPanel.panDown());
        timeSlow.addActionListener(e -> simPanel.timeSlow());
        timeFast.addActionListener(e -> simPanel.timeFast());
        
        // Füge Steuerelemente hinzu
        control.add(zoomIn);
        control.add(zoomOut);
        control.add(panLeft);
        control.add(panRight);
        control.add(panUp);
        control.add(panDown);
        control.add(timeSlow);
        control.add(timeFast);
        
        return control;
    }
}

// Innere Klassen, die in der gleichen Datei definiert werden
class KreisObjekt {
    double size;
    double red;
    double green;
    double blue;
    double posX;
    double posY;
    double posZ;
    double vx;
    double vy;
    double vz;
    
    public KreisObjekt(double size, double red, double green, double blue, 
                      double posX, double posY, double posZ,
                      double vx, double vy, double vz) {
        this.size = size;
        this.red = red;
        this.green = green;
        this.blue = blue;
        this.posX = posX;
        this.posY = posY;
        this.posZ = posZ;
        this.vx = vx;
        this.vy = vy;
        this.vz = vz;
    }
    
    public KreisObjekt(double size, double red, double green, double blue, 
                      double posX, double posY, double posZ) {
        this(size, red, green, blue, posX, posY, posZ, 0, 0, 0);
    }
    
    public KreisObjekt(double posX, double posY) {
        this(10.0, 255, 0, 0, posX, posY, 0);
    }
    
    public KreisObjekt() {
        this.size = 5000;
        Random rand = new Random();
        this.red = 255 * rand.nextDouble();
        this.green = 255 * rand.nextDouble();
        this.blue = 255 * rand.nextDouble();
        this.posX = (rand.nextDouble() - 0.5) * 10000;
        this.posY = (rand.nextDouble() - 0.5) * 10000;
        this.posZ = 0;
        this.vx = 0;
        this.vy = 0;
        this.vz = 0;
    }
    
    public void move(double time) {
        posX += vx * time;
        posY += vy * time;
        posZ += vz * time;
    }
    
    public double colordif(KreisObjekt other) {
        double difR = red - other.red;
        double difG = green - other.green;
        double difB = blue - other.blue;
        double difQ = difR * difR + difG * difG + difB * difB;
        return Math.sqrt(difQ);
    }
}

class Unit extends KreisObjekt {
    double maxLeben;
    double leben;
    double damage;
    double distance;
    double speed;
    int team;
    int kills;
    public Unit target = null;
    
    public Unit() {
        super();
        Random rand = new Random();
        this.leben = 50 + rand.nextDouble() * 100;
        this.maxLeben = leben;
        this.damage = 5 + rand.nextDouble() * 10;
        this.distance = 5000 + rand.nextDouble() * 5000;
        this.speed = 1000 + rand.nextDouble() * 3000;
        this.team = rand.nextInt(5) + 1;
        this.size = 5000;
        this.größePerLive(1);
    }
    
    public void moveTo(KreisObjekt oponent) {
        double dist = getDistance(oponent);
        if (dist < 1) return; // Vermeide Division durch Null
        
        double dx = oponent.posX - posX;
        double dy = oponent.posY - posY;
        double dz = oponent.posZ - posZ;
        
        double movDist = Math.min(speed, dist);
        
        vx = dx / dist * movDist;
        vy = dy / dist * movDist;
        vz = dz / dist * movDist;
    }
    
    public double getDistance(KreisObjekt oponent) {
        double distX = posX - oponent.posX;
        double distY = posY - oponent.posY;
        double distZ = posZ - oponent.posZ;
        return Math.sqrt(distX * distX + distY * distY + distZ * distZ);
    }
    
    public void größePerLive(double div) {
        double size = Math.pow(leben / div, 0.3333) * 100;
        size = Math.max(1000, Math.min(size, 10000)); // Begrenze die Größe
        this.size = size;
    }
}