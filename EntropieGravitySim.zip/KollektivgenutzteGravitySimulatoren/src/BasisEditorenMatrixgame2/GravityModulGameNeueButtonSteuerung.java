package BasisEditorenMatrixgame2;

/*
 * Auf der Basis des Infinityzooms, der sich in dem von mir geplanten Kollektiven Matrixgame
 * im Internet und auf vielen weiteren geigneten Ebenen sehr gut eignet, zum beispiel etwa auch für die nächst 
 * Windowsupdates für einen verbesserten Desktop oder für eine schönere Suche und Suchansicht im Internet...
 * Hier rauf habe ich eine eigene Buttonteuerung aufgebaut, die ich sehr gerne so erweitern würde,
 * dass sich so viele Projekte und anwendungen wie nur möglich über diese Basis Gamifizieren, Planen, Simulieren und Realisieren 
 * lassen werden. Als nächstes habe ich eine weitere Spalte mit Buttons für Mathematische und Naturwissenschaftliche 
 * Operationen innerhal des Canvas geplant um anschließen mit diesen in der Lage zu sein, die Massekugeln im 
 * 3D Raum so zu strukturieren, dass diese basierend auf den Gesetzen nach Newton in einer übergeordneten Gravitativ wechselwirkenden Struktur
 * über die Zeit erhalten bleiben und somit validiert werden können, als Basisteilchen für die nächst größeren Materie und 
 * Massestrukturen bzw. jenen am besten für größere Module geeigneten Verbindungen von mehreren Massepunkten bzw. Teilmassen zu einer stabilen 
 * und geeigneten nächst größeren Form des Massepunktes, so dass sich endlos daraf aufbauen lässt und womöglich alle Gesetze einer
 * Vereinheitlichung der Grundkräfte bereits hierauf basierend Kollektiv und Gamifiziert Generiert werden können. In diesem Sinne wäre dann noch
 * eine geeignete Realisierung im Internet die von den Richtigen Menschen auf die richtige Art und Weise entdeckt werden kann bzw. dies hoffentlich
 * früher oder später generell geschehen lässst. Ich werde den Code erneut auf Google Drive hoch laden, so das dieser in Zukunft wie üblich auf so
 * vielen Ebenen wie es aktuell realisiert werden kann und gewollt ist, genutzt, entwickelt und geteilt werden kann und hoffentlich auch zu Freundschaften, Kooperationen
 * bzw, einer von mir sehr gesuchten und sehr wertvollen realen Form einer Gemeinsamen Arbeit mit anderen Menschen an meinen Visionen und dem Kollektiven Matrixgame. 
 * Link zu meinem Matrixgame-Journal:  https://docs.google.com/document/d/1J_qc7-O3qbUb8WOyBHNnLkcEEQ5JklY4d9vmd67RtC4/edit?tab=t.0
 * Vielen Dank, Let's Go
 */

import javax.swing.*;
import p1.MasseKugel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GravityModulGameNeueButtonSteuerung extends JPanel implements MouseListener {

    // --- Simulationskonstanten ---
    int FRAME_WIDTH = 1920;
    int FRAME_HEIGHT = 1080;

    // --- Zoom-Variablen ---
    private double zoomFactor = 1.0;
    double zoomCenterX = 0;
    double zoomCenterY = 0;
    static final double ZOOM_STEP = 1.2;
    double feinheit = 70;
    double PAN_STEP = feinheit * zoomFactor;

    double time = 1.0;
    long pause = 100;

    String[] buttonNames = new String[10];
    double[] buttonValues1 = new double[10];
    String[] buttonValues = new String[10];

    ArrayList<MasseKugel> erschaffen = new ArrayList<MasseKugel>();
    ArrayList<MasseKugel> bausteine = new ArrayList<MasseKugel>();

    double G = 0.000001;
    double stepps = 1;

    // --- Konstruktor ---
    public GravityModulGameNeueButtonSteuerung() {
        bausteine.add(new MasseKugel(15, 0, 0, 0, Math.sqrt(G*3000/15), 0, 1, 5, new Color(100, 0, 0)));
        bausteine.add(new MasseKugel(0, 0, 0, 0, 0, 0, 2, 5, new Color(0, 100, 0)));
        bausteine.add(new MasseKugel(0, 0, 0, 0, 0, 0, 3000, 5, new Color(0, 0, 100)));

        setPreferredSize(new Dimension(FRAME_WIDTH, FRAME_HEIGHT));
        setBackground(Color.BLACK);
        addMouseListener(this);

        // Initialisierung der Button-Werte
        for (int i = 0; i < 10; i++) {
            buttonValues1[i] = 0;
            buttonValues[i] = "0";
        }

        buttonNames[0] = "BodyNumber";
        buttonNames[1] = "PosX";
        buttonNames[2] = "PosY";
        buttonNames[3] = "PosZ";
        buttonNames[4] = "VX";
        buttonNames[5] = "VY";
        buttonNames[6] = "VZ";
        buttonNames[7] = "Mass";
        buttonNames[8] = "Radius";
        buttonNames[9] = "Mod";
    }

    // --- Pan-Methoden ---
    public void panLeft() {
        zoomCenterX += PAN_STEP;
        repaint();
    }

    public void panRight() {
        zoomCenterX -= PAN_STEP;
        repaint();
    }

    public void panUp() {
        zoomCenterY += PAN_STEP;
        repaint();
    }

    public void panDown() {
        zoomCenterY -= PAN_STEP;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        // Zeichne alle erstellten Massekugeln
        for (MasseKugel body : erschaffen) {
            double radius = body.radius * zoomFactor;
            radius = Math.max(3, radius);
            radius = Math.min(13, radius);
            Color color = body.color;
            double posX = body.x;
            double posY = body.y;
            
            double sx = (zoomCenterX + posX) * zoomFactor + getWidth() / 2.0;
            double sy = (zoomCenterY + posY) * zoomFactor + getHeight() / 2.0;
            
            g2.setColor(color);
            g2.fillOval((int) (sx - radius), (int) (sy - radius), (int) (radius * 2), (int) (radius * 2));
        }

        // Zeichne Buttons
        g2.setColor(new Color(0, 0, 255));
        for (int i = 0; i < buttonZahl; i++) {
            g2.drawRect((int) buttonPosX, (int) (buttonHohe * i), (int) buttonBreite, 80);
            g2.drawString(buttonNames[i], (int) buttonPosX + 5, (int) (buttonHohe * i) + 20);
            g2.drawString(buttonValues[i], (int) buttonPosX + 5, (int) (buttonHohe * i) + 40);
        }
    }

    // --- MouseListener ---
    double buttonPosX = 1400;
    double buttonBreite = 100.0;
    double buttonHohe = 80;
    int buttonOptionen = 5;
    int buttonZahl = 10;
    double[] incdec = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1};

    @Override
    public void mousePressed(MouseEvent e) {
        int mouseX = e.getX();
        int mouseY = e.getY();
        
        for (int i = 0; i < buttonZahl; i++) {
            int buttonY = (int) (buttonHohe * i);
            
            // Button-Spalten
            if (mouseY >= buttonY && mouseY < buttonY + 80) {
                double columnWidth = buttonBreite / buttonOptionen;
                
                // Spalte 0: Reset
                if (mouseX >= buttonPosX && mouseX < buttonPosX + columnWidth) {
                    buttonValues1[i] = 0;
                    incdec[i]=1;
                    buttonValues[i] = String.valueOf(buttonValues1[i]);
                    setValues();
                    repaint();
                }
                // Spalte 1: Erhöhen
                else if (mouseX >= buttonPosX + columnWidth && mouseX < buttonPosX + 2 * columnWidth) {
                    buttonValues1[i] += incdec[i];
                    buttonValues[i] = String.valueOf(buttonValues1[i]);
                    setValues();
                    repaint();
                }
                // Spalte 2: Increment verdoppeln
                else if (mouseX >= buttonPosX + 2 * columnWidth && mouseX < buttonPosX + 3 * columnWidth) {
                    incdec[i] *= 2.0;
                    buttonValues[i] = String.valueOf(buttonValues1[i]);
                    setValues();
                    repaint();
                }
                // Spalte 3: Verringern
                else if (mouseX >= buttonPosX + 3 * columnWidth && mouseX < buttonPosX + 4 * columnWidth) {
                    buttonValues1[i] -= incdec[i];
                    buttonValues[i] = String.valueOf(buttonValues1[i]);
                    setValues();
                    repaint();
                }
                // Spalte 4: Increment halbieren
                else if (mouseX >= buttonPosX + 4 * columnWidth && mouseX < buttonPosX + 5 * columnWidth) {
                    incdec[i] /= 2.0;
                    buttonValues[i] = String.valueOf(buttonValues1[i]);
                    setValues();
                    repaint();
                }
            }
        }
    }

    public void setValues() {
        int selectedIndex = (int) buttonValues1[0];
        
        if (selectedIndex >= 0 && selectedIndex < bausteine.size()) {
            MasseKugel selectedBaustein = bausteine.get(selectedIndex);
            
            selectedBaustein.x = buttonValues1[1];
            selectedBaustein.y = buttonValues1[2];
            selectedBaustein.z = buttonValues1[3];
            selectedBaustein.vx = buttonValues1[4];
            selectedBaustein.vy = buttonValues1[5];
            selectedBaustein.vz = buttonValues1[6];
            selectedBaustein.ax = buttonValues1[7];
            selectedBaustein.ay = buttonValues1[8];
            selectedBaustein.az = buttonValues1[9];
        }
    }

    public void setButtonValues() {
        int selectedIndex = (int) buttonValues1[0];
        
        if (selectedIndex >= 0 && selectedIndex < bausteine.size()) {
            MasseKugel selectedBaustein = bausteine.get(selectedIndex);
            
            buttonValues1[1] = selectedBaustein.x;
            buttonValues1[2] = selectedBaustein.y;
            buttonValues1[3] = selectedBaustein.z;
            buttonValues1[4] = selectedBaustein.vx;
            buttonValues1[5] = selectedBaustein.vy;
            buttonValues1[6] = selectedBaustein.vz;
            buttonValues1[7] = selectedBaustein.ax;
            buttonValues1[8] = selectedBaustein.ay;
            buttonValues1[9] = selectedBaustein.az;
            
            for (int i = 1; i < buttonZahl; i++) {
                buttonValues[i] = String.valueOf(buttonValues1[i]);
            }
        }
    }

    // Ungenutzte MouseListener-Methoden
    @Override
    public void mouseReleased(MouseEvent e) {}
    @Override
    public void mouseEntered(MouseEvent e) {}
    @Override
    public void mouseExited(MouseEvent e) {}
    @Override
    public void mouseClicked(MouseEvent e) {}

    // --- Zoom ---
    public void zoomIn() {
        zoomFactor *= ZOOM_STEP;
        PAN_STEP = feinheit / zoomFactor;
        repaint();
    }

    public void zoomOut() {
        zoomFactor /= ZOOM_STEP;
        PAN_STEP = feinheit / zoomFactor;
        repaint();
    }

    public void generate() {
        int selectedIndex = (int) buttonValues1[0];
        
        if (selectedIndex >= 0 && selectedIndex < bausteine.size()) {
            MasseKugel current = bausteine.get(selectedIndex);
            MasseKugel kopie = new MasseKugel(
                current.x, current.y, current.z,
                current.vx, current.vy, current.vz,
                current.mass, current.radius, current.color
            );
            kopie.ax = current.ax;
            kopie.ay = current.ay;
            kopie.az = current.az;
            kopie.rot = current.rot;
            kopie.green = current.green;
            kopie.blue = current.blue;
            
            erschaffen.add(kopie);
            repaint();
        }
    }

    public void bausteinUpgrade() {
        // Implementierung später
    }

    public void play() {
        int iterations = (int) buttonValues1[0];
        
        for (int i = 0; i < iterations; i++) {
            timeStep();
        }
        repaint();
    }

    public void timeStep() {
        GravityGemini();
        for (MasseKugel current : erschaffen) {
            current.updatePosition(time);
            current.updateV(time);
        }
    }

    public void GravityGemini() {
        for (int i2 = 0; i2 < stepps; i2++) {
            int n = erschaffen.size();
            double[] ax = new double[n];
            double[] ay = new double[n];
            double[] az = new double[n];
            
            for (int i = 0; i < n; i++) {
                MasseKugel bi = erschaffen.get(i);
                ax[i] = ay[i] = az[i] = 0;
                
                if (!bi.movable) continue;
                
                for (int j = 0; j < n; j++) {
                    if (i == j) continue;
                    
                    MasseKugel bj = erschaffen.get(j);
                    double dx = bj.x - bi.x;
                    double dy = bj.y - bi.y;
                    double dz = bj.z - bi.z;
                    double r2 = dx * dx + dy * dy + dz * dz;
                    double r = Math.sqrt(r2);
                    
                    if (r == 0) continue;
                    
                    double a = G * bj.mass / r2;
                    ax[i] += a * dx / r;
                    ay[i] += a * dy / r;
                    az[i] += a * dz / r;
                }
            }
            
            for (int i = 0; i < n; i++) {
                MasseKugel b = erschaffen.get(i);
                if (b.movable) {
                    b.vx += ax[i];
                    b.vy += ay[i];
                    b.vz += az[i];
                }
            }
        }
        repaint();
    }

    public void analyseMasseKugel(MasseKugel mk, int mode) {
        if (mode == 0) {
            buttonValues[1] = String.valueOf(mk.x);
            buttonValues1[1] = mk.x;
            buttonValues[2] = String.valueOf(mk.y);
            buttonValues1[2] = mk.y;
            buttonValues[3] = String.valueOf(mk.z);
            buttonValues1[3] = mk.z;
            buttonValues[4] = String.valueOf(mk.vx);
            buttonValues1[4] = mk.vx;
            buttonValues[5] = String.valueOf(mk.vy);
            buttonValues1[5] = mk.vy;
            buttonValues[6] = String.valueOf(mk.vz);
            buttonValues1[6] = mk.vz;
            buttonValues[7] = String.valueOf(mk.mass);
            buttonValues1[7] = mk.mass;
            buttonValues[8] = String.valueOf(mk.radius);
            buttonValues1[8] = mk.radius;
        } else if (mode == 1) {
            buttonValues[1] = String.valueOf(mk.ax);
            buttonValues1[1] = mk.ax;
            buttonValues[2] = String.valueOf(mk.ay);
            buttonValues1[2] = mk.ay;
            buttonValues[3] = String.valueOf(mk.az);
            buttonValues1[3] = mk.az;
            buttonValues[4] = String.valueOf(mk.rot);
            buttonValues1[4] = mk.rot;
            buttonValues[5] = String.valueOf(mk.green);
            buttonValues1[5] = mk.green;
            buttonValues[6] = String.valueOf(mk.blue);
            buttonValues1[6] = mk.blue;
        }
        repaint();
    }

    // Neue Methode für Analyse-Button
    public void analyseCurrent() {
        int selectedIndex = (int) buttonValues1[0];
        int mod=(int) buttonValues1[9];
        if (selectedIndex >= 0 && selectedIndex < bausteine.size()) {
            analyseMasseKugel(bausteine.get(selectedIndex), mod);
        }
    }

    // --- main ---
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("N-Body Sonnensystem-Simulation (QDBV-Modul)");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            GravityModulGameNeueButtonSteuerung simPanel = new GravityModulGameNeueButtonSteuerung();

            frame.setLayout(new BorderLayout());
            frame.add(simPanel, BorderLayout.CENTER);

            // Buttons erstellen
            JButton zoomIn = new JButton("Zoom In");
            JButton zoomOut = new JButton("Zoom Out");
            JButton speedUp = new JButton("Speed Up");
            JButton speedDown = new JButton("Speed Down");
            JButton panLeft = new JButton("← Links");
            JButton panRight = new JButton("Rechts →");
            JButton panUp = new JButton("↑ Hoch");
            JButton panDown = new JButton("↓ Runter");
            JButton generate = new JButton("Generate");
            JButton play = new JButton("Play");
            JButton analyse = new JButton("Analyse");

            // ActionListener
            zoomIn.addActionListener(e -> simPanel.zoomIn());
            zoomOut.addActionListener(e -> simPanel.zoomOut());
            panLeft.addActionListener(e -> simPanel.panLeft());
            panRight.addActionListener(e -> simPanel.panRight());
            panUp.addActionListener(e -> simPanel.panUp());
            panDown.addActionListener(e -> simPanel.panDown());
            generate.addActionListener(e -> simPanel.generate());
            play.addActionListener(e -> simPanel.play());
            analyse.addActionListener(e -> simPanel.analyseCurrent());

            // Control Panel
            JPanel control = new JPanel();
            control.add(zoomIn);
            control.add(zoomOut);
            control.add(speedUp);
            control.add(speedDown);
            control.add(panLeft);
            control.add(panRight);
            control.add(panUp);
            control.add(panDown);
            control.add(generate);
            control.add(play);
            control.add(analyse);

            frame.add(control, BorderLayout.NORTH);
            frame.setSize(1920, 1080);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}