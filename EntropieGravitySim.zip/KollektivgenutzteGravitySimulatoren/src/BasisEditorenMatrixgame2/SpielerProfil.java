
package BasisEditorenMatrixgame2;
// NEUE KLASSIFIZIERUNG: Psychische Zustände
enum PsychischerZustand {
    FLOW, ANGST, PERFEKTIONISMUS, RESILIENZ, BURNOUT
}

public class SpielerProfil {
    private double erwachsenenWiderstand = 0.7; // 0.0-1.0 Skala
    private double telesonEnergieEffizienz = 0.85; // Vertriebseffizienz
    
    public void verarbeiteMisserfolg() {
        if (this.erwachsenenWiderstand > 0.5) {
            // AKTIVIERE KI-UNTERSTÜTZUNG
            MatrixgameKern.aktiviereMentaleBrücke();
            this.erwachsenenWiderstand *= 0.9; // Reduktion durch kollektive Intelligenz
        }
    }
}