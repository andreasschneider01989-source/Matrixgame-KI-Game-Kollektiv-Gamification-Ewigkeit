package BasisEditorenMatrixgame2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SchönerZoom2FormScaleUnitsFightsBasicColorGame extends JPanel {

    // --- Instanzvariablen (NICHT static) ---
    private int FRAME_WIDTH = 1920;
    private int FRAME_HEIGHT = 1080;
    private double zoomFactor = 1.0;
    private double zoomCenterX = 0;
    private double zoomCenterY = 0;
    private static final double ZOOM_STEP = 1.2;
    private double feinheit = 70;
    
    // volatile für sichere Thread-Kommunikation
    private volatile double pause = 1000.0;
    
    private double PAN_STEP;

    // --- Tracking-Variablen ---
    private volatile Unit selectedUnit = null; // Die zu verfolgende Einheit
    private volatile boolean isFollowing = false; // Steuert die Kamera-Verfolgung
    
    // Wichtig: unitList als Instanzvariable
    private List<Unit> unitList = new ArrayList<>();

    // --- Konstruktor ---
    public SchönerZoom2FormScaleUnitsFightsBasicColorGame() {
        initializeSettings();
        initializeUnits();
        setupPanel();
    }

    private void initializeSettings() {
        PAN_STEP = feinheit * zoomFactor;
    }

    double size = 500000;
    private void initializeUnits() {
        // Units hier hinzufügen - nicht in main!
        for (int i = 0; i < 10000; i++) {
            Unit Unit1 = new Unit();
            Unit1.team = 1;
            Unit1.posX += (size * Math.random() - 0.5 * size);
            Unit1.posY += (size * Math.random() - 0.5 * size);
            Unit1.posZ -= 0;
            Unit1.blue = 0;
            Unit1.red = 254;
            Unit1.green = 0;

            Unit Unit2 = new Unit();
            Unit2.team = 2;
            Unit2.posX += (size * Math.random() - 0.5 * size);
            Unit2.posY += (size * Math.random() - 0.5 * size);
            Unit2.posZ -= 0;
            Unit2.blue = 0;
            Unit2.red = 0;
            Unit2.green = 254;

            Unit Unit3 = new Unit();
            Unit3.team = 3;
            Unit3.red = 0;
            Unit3.green = 0;
            Unit3.blue = 254;
            Unit3.posX += (size * Math.random() - 0.5 * size);
            Unit3.posY += (size * Math.random() - 0.5 * size);
            Unit3.posZ += 0;
            
            Unit Unit4 = new Unit();
            Unit4.team = 4;
            Unit4.posX += (size * Math.random() - 0.5 * size);
            Unit4.posY += (size * Math.random() - 0.5 * size);
            Unit4.posZ -= 0;
            Unit4.blue = 254;
            Unit4.red = 254;
            Unit4.green = 0;

            Unit Unit5 = new Unit();
            Unit5.team = 5;
            Unit5.posX += (size * Math.random() - 0.5 * size);
            Unit5.posY += (size * Math.random() - 0.5 * size);
            Unit5.posZ -= 0;
            Unit5.blue = 254;
            Unit5.red = 0;
            Unit5.green = 254;

            Unit Unit6 = new Unit();
            Unit6.team = 6;
            Unit6.red = 254;
            Unit6.green = 254;
            Unit6.blue = 0;
            Unit6.posX += (size * Math.random() - 0.5 * size);
            Unit6.posY += (size * Math.random() - 0.5 * size);
            Unit6.posZ += 0;
            
            Unit Unit7 = new Unit();
            Unit7.red = Math.random()*255;
            Unit7.green = Math.random()*255;
            Unit7.blue = Math.random()*255;
            Unit7.team = 7;
            Unit7.posX += (size * Math.random() - 0.5 * size);
            Unit7.posY += (size * Math.random() - 0.5 * size);
            Unit7.posZ += 0;

//            unitList.add(Unit1);
//            unitList.add(Unit2);
//            unitList.add(Unit3);
//            unitList.add(Unit4);
//            unitList.add(Unit5);
//            unitList.add(Unit6);
            unitList.add(Unit7);
        }
    }

    private void setupPanel() {
        setPreferredSize(new Dimension(FRAME_WIDTH, FRAME_HEIGHT));
        setBackground(Color.BLACK);
        // NEU: Maus-Listener hinzufügen
        addMouseListener(new UnitClickListener());
    }

    // --- Game Loop als Instanzmethode ---
    public void startGameLoop() {
        Thread gameThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    // Verwende volatile pause (als long gecastet)
                    Thread.sleep((long) pause);
                    updateGameState();
                    updateCamera(); // Kamera-Position aktualisieren
                    repaint(); // Kann jetzt aufgerufen werden, da Instanzmethode
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        gameThread.setDaemon(true); // Wird beendet wenn Fenster geschlossen
        gameThread.start();
    }
    
    /**
     * Aktualisiert die Kamera-Position, um der ausgewählten Einheit zu folgen.
     */
    private void updateCamera() {
        if (isFollowing && selectedUnit != null) {
            // Zentriere die Kamera auf die Weltkoordinaten der Einheit
            zoomCenterX = -selectedUnit.posX;
            zoomCenterY = -selectedUnit.posY;
        }
    }

    // Diese Funktion bleibt O(N), wird aber jetzt seltener aufgerufen.
    public Unit nextGegner(Unit current) {
        Unit gegner = null; 
        double min = Double.MAX_VALUE;
        // Achtung: Iteriert über die gesamte unitList!
        for (Unit unit : unitList) {
            if (current.getDistance(unit) < min && current.colordif(unit) > 1000*Math.random()) {
                min = current.getDistance(unit);
                gegner = unit;
            }
        }
        return gegner;
    }

    private void updateGameState() {
        List<Unit> toRemove = new ArrayList<>(); // Units die entfernt werden sollen

        // Iteration über unitList 
        for (Unit unit : unitList) {
            
            // Suche nur neuen Gegner, wenn der aktuelle tot ist oder nicht existiert
            // VORAUSSETZUNG: Die Klasse Unit hat ein Feld 'public Unit target;'
            if (unit.target == null || unit.target.leben <= 0 || Math.random()>0.95) {
                unit.target = nextGegner(unit); // Aufruf der O(N) Funktion nur bei Bedarf
            }
            
            Unit gegner = unit.target;
            
            if (gegner != null) {
                if (unit.getDistance(gegner) <= unit.distance) {
                    // Angriff
                    gegner.leben = gegner.leben - unit.damage;
                    gegner.größePerKills(1);
                    
                    while(gegner.leben<=0) {
                    if(gegner.leben <= 0&&Math.random()>0.5) {
                    	gegner.leben=gegner.maxLeben;
                    	gegner.red=unit.red;
                    }
                    if(gegner.leben <= 0&&Math.random()>0.5) {
                    	gegner.leben=gegner.maxLeben;
                    	gegner.green=unit.green;
                    }
                    if(gegner.leben <= 0&&Math.random()>0.5) {
                    	gegner.leben=gegner.maxLeben;
                    	gegner.blue=unit.blue;
                    }
//                    if(Math.random()>0.5)gegner.posX+=(Math.random()/Math.random()*size);
//                    if(Math.random()>0.5)gegner.posY+=(Math.random()/Math.random()*size);
//                    if(Math.random()>0.5)gegner.posX-=(Math.random()/Math.random()*size);
//                    if(Math.random()>0.5)gegner.posY-=(Math.random()/Math.random()*size);
                    gegner.kills=0;
                    unit.kills++;
                    unit.leben=unit.maxLeben;
                    unit.target=null;
                    
                    }
                    if(gegner.leben <= 0&&Math.random()>0.5) {
                    	gegner.leben=gegner.maxLeben;
                    	gegner.red=unit.red;
                    }
                    if(gegner.leben <= 0&&Math.random()>0.5) {
                    	gegner.leben=gegner.maxLeben;
                    	gegner.green=unit.green;
                    }
                    if(gegner.leben <= 0&&Math.random()>0.5) {
                    	gegner.leben=gegner.maxLeben;
                    	gegner.blue=unit.blue;
                    }
                    if(gegner.leben <= 0&&Math.random()>0.5) {
                    	gegner.leben=gegner.maxLeben;
                    	gegner.red=unit.red;
                    }
                    if(gegner.leben <= 0&&Math.random()>0.5) {
                    	gegner.leben=gegner.maxLeben;
                    	gegner.green=unit.green;
                    }
                    if(gegner.leben <= 0&&Math.random()>0.5) {
                    	gegner.leben=gegner.maxLeben;
                    	gegner.blue=unit.blue;
                    }
                    
                    
                    if (gegner.leben <= 0) {
                    	
                    	
                    	
                    	unit.kills++;
                        
                        // =========================================================
                        // === NEUE LOGIK: ÜBERGABE DER KAMERA AUF DEN ANGREIFER ===
                        // =========================================================
                        if (isFollowing && gegner == selectedUnit) {
                            // Die verfolgte Einheit (gegner) wurde getötet.
                            // Der Angreifer (unit) wird zur neuen verfolgten Einheit.
                            selectedUnit = unit;
                            // isFollowing bleibt true, die Kamera folgt ab sofort dem Killer.
                        }
                        // =========================================================
                        
                        toRemove.add(gegner); // Markiere zum Entfernen
                    }
                } else {
                    // Bewegung
                    unit.moveTo(gegner);
                    unit.move(1);
                    unit.größePerKills(1);
                }
            }
        }

        // Entferne alle markierten Units AUßERHALB der Iteration
        unitList.removeAll(toRemove);

        // Verfolgung beenden, falls die verfolgte Einheit entfernt wurde 
        if (isFollowing && selectedUnit != null && selectedUnit.leben <= 0) {
            isFollowing = false;
            selectedUnit = null;
        }
    }

    // --- Pan-Methoden ---
    // Die manuelle Bewegung stoppt die Verfolgung
    public void panLeft() {
        isFollowing = false;
        zoomCenterX += PAN_STEP;
        repaint();
    }

    public void panRight() {
        isFollowing = false;
        zoomCenterX -= PAN_STEP;
        repaint();
    }

    public void panUp() {
        isFollowing = false;
        zoomCenterY += PAN_STEP;
        repaint();
    }

    public void panDown() {
        isFollowing = false;
        zoomCenterY -= PAN_STEP;
        repaint();
    }

    // --- Zoom-Methoden ---
    public void zoomIn() {
        zoomFactor *= ZOOM_STEP;
        updatePanStep();
        repaint();
    }

    public void zoomOut() {
        zoomFactor /= ZOOM_STEP;
        updatePanStep();
        repaint();
    }

    // --- Zeitkontrolle (mit volatile double pause) ---
    public void timeFast() {
        pause /= ZOOM_STEP;
        if (pause < 1) pause = 1; // Minimum-Pause (1ms)
    }

    public void timeSlow() {
        pause *= ZOOM_STEP;
    }

    private void updatePanStep() {
        PAN_STEP = feinheit / zoomFactor; 
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, getWidth(), getHeight());
        
        // Temporäre Kopie für thread-sicheres Zeichnen im EDT
        List<Unit> safeUnitList;
        synchronized (unitList) {
            safeUnitList = new ArrayList<>(unitList);
        }

        for (Unit current : safeUnitList) {
            // Radius wird NICHT mit zoomFactor skaliert
            double radius = Math.abs(current.size);
            
            Color color = new Color(
                    (int) Math.abs(current.red % 255),
                    (int) Math.abs(current.green % 255),
                    (int) Math.abs(current.blue % 255)
            );

            // Umrechnung von Weltkoordinaten zu Bildschirmkoordinaten (Position wird skaliert)
            double sx = (zoomCenterX + current.posX) * zoomFactor + getWidth() / 2.0;
            double sy = (zoomCenterY + current.posY) * zoomFactor + getHeight() / 2.0;

            g2.setColor(color);
            g2.fillOval((int) (sx - radius), (int) (sy - radius),
                        (int) (radius * 2), (int) (radius * 2));
            
            // Hebe die ausgewählte Einheit hervor
            if (current == selectedUnit) {
                g2.setColor(Color.YELLOW);
                // Zeichne einen gelben Ring um die Einheit
                g2.drawOval((int) (sx - radius - 2), (int) (sy - radius - 2),
                            (int) (radius * 2 + 4), (int) (radius * 2 + 4));
            }
        }
    }
    
    // --- PRIVATE INNER CLASS: UNIT SELECTION HANDLER ---
    private class UnitClickListener extends MouseAdapter {
        @Override
        public void mousePressed(MouseEvent e) {
            
            synchronized (unitList) {
                // Iteriere rückwärts, um zuerst die "oberste" (zuletzt gezeichnete) Einheit zu treffen
                for (int i = unitList.size() - 1; i >= 0; i--) {
                    Unit current = unitList.get(i);

                    // 1. Berechne die Bildschirmkoordinaten der Einheit
                    double sx = (zoomCenterX + current.posX) * zoomFactor + getWidth() / 2.0;
                    double sy = (zoomCenterY + current.posY) * zoomFactor + getHeight() / 2.0;
                    
                    // 2. Radius für die Hitbox (NICHT skaliert)
                    double radius = Math.abs(current.size);
                    
                    // 3. Berechne die Distanz zwischen Mausklick und Einheitszentrum
                    double dx = e.getX() - sx;
                    double dy = e.getY() - sy;
                    double distance = Math.sqrt(dx * dx + dy * dy);

                    // 4. Prüfe, ob der Klick innerhalb des Radius lag
                    if (distance <= radius) {
                        if (current == selectedUnit) {
                            // Wenn die bereits ausgewählte Einheit erneut geklickt wird, stoppe die Verfolgung
                            isFollowing = false;
                            selectedUnit = null;
                        } else {
                            // Wähle die neue Einheit aus und starte die Verfolgung
                            selectedUnit = current;
                            isFollowing = true;
                        }
                        repaint(); // Neuzeichnen, um die Auswahl hervorzuheben
                        return; // Beende die Schleife nach dem ersten Treffer
                    }
                }
            }
            
            // Wenn keine Einheit getroffen wurde und Tracking aktiv war, stoppe Tracking
            if (isFollowing) {
                isFollowing = false;
                selectedUnit = null;
                repaint();
            }
        }
    }

    // --- MAIN METHODE - Nur Einstiegspunkt (UNVERÄNDERT) ---
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            createAndShowGUI();
        });
    }

    private static void createAndShowGUI() {
        // 1. Hauptpanel erstellen
        SchönerZoom2FormScaleUnitsFightsBasicColorGame simPanel = new SchönerZoom2FormScaleUnitsFightsBasicColorGame();

        // 2. Frame erstellen und konfigurieren
        JFrame frame = new JFrame("N-Body Sonnensystem-Simulation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.add(simPanel, BorderLayout.CENTER);

        // 3. Steuerelemente hinzufügen
        frame.add(createControlPanel(simPanel), BorderLayout.NORTH);

        // 4. Frame anzeigen
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // 5. Game Loop starten
        simPanel.startGameLoop();
    }

    private static JPanel createControlPanel(SchönerZoom2FormScaleUnitsFightsBasicColorGame simPanel) {
        JPanel control = new JPanel();

        JButton zoomIn = new JButton("Zoom In");
        JButton zoomOut = new JButton("Zoom Out");
        JButton panLeft = new JButton("← Links");
        JButton panRight = new JButton("Rechts →");
        JButton panUp = new JButton("↑ Hoch");
        JButton panDown = new JButton("↓ Runter");
        JButton timeSlow = new JButton("Time Slow");
        JButton timeFast = new JButton("Time Fast");

        zoomIn.addActionListener(e -> simPanel.zoomIn());
        zoomOut.addActionListener(e -> simPanel.zoomOut());
        panLeft.addActionListener(e -> simPanel.panLeft());
        panRight.addActionListener(e -> simPanel.panRight());
        panUp.addActionListener(e -> simPanel.panUp());
        panDown.addActionListener(e -> simPanel.panDown());
        timeSlow.addActionListener(e -> simPanel.timeSlow());
        timeFast.addActionListener(e -> simPanel.timeFast());

        control.add(zoomIn);
        control.add(zoomOut);
        control.add(panLeft);
        control.add(panRight);
        control.add(panUp);
        control.add(panDown);
        control.add(timeSlow);
        control.add(timeFast);

        return control;
    }
}