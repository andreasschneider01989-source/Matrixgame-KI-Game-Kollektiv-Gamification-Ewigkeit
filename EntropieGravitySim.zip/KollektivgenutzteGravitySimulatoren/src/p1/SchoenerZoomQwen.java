package p1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Advanced N-Body Gravitation Simulation with Scientific Time Control
 * 
 * Features:
 * - Real-time as baseline (1 simulation second = 1 real second)
 * - Exponential time scaling (factor of 2 per keypress)
 * - Beautiful zoom and navigation
 * - Scientific visualization of 3I/ATLAS trajectory
 * 
 * @author Andreas Schneider
 * @version 2.2 (Time Control Enhanced)
 */
public class SchoenerZoomQwen extends JPanel implements ActionListener {
    
    // ===== Scientific Constants & Configuration =====
    private static final double GRAVITATIONAL_CONSTANT = 6.67430e-11; // m^3 kg^-1 s^-2
    private static final double AU = 1.496e11; // Astronomical Unit in meters
    private static final double SOLAR_MASS = 1.989e30; // kg
    private static final double EARTH_MASS = 5.972e24; // kg
    private static final double EARTH_ORBITAL_PERIOD = 365.25 * 24 * 3600; // seconds
    
    // ===== Simulation Parameters =====
    private static final int FRAME_WIDTH = 1920;
    private static final int FRAME_HEIGHT = 1080;
    private static final double BASE_TIME_STEP = 1.0; // seconds per physics step
    
    // ===== Visualization Parameters =====
    private double zoomFactor = 1.0;
    private double zoomCenterX = 0;
    private double zoomCenterY = 0;
    private static final double ZOOM_STEP = 1.2;
    private static final int MIN_RADIUS_DRAW = 2;
    private static final double PAN_STEP_BASE = 0.5 * AU; // 0.5 AU base pan step
    
    // ===== TIME CONTROL SYSTEM =====
    private double timeScale = 1.0; // 1.0 = real-time (1 sim second = 1 real second)
    private static final double TIME_SCALE_STEP = 1.2; // Exponential factor (doubles/halves speed)
    private static final double MIN_TIME_SCALE = 1e-6; // 1 microsecond per real second
    private static final double MAX_TIME_SCALE = 1e9;  // 1 billion seconds per real second (~31 years)
    private double accumulatedTime = 0;
    private long lastFrameTime = System.currentTimeMillis();
    
    // ===== Simulation State =====
    private final List<CelestialBody> bodies = new ArrayList<>();
    private final Random random = new Random();
    private double simulationTime = 0.0; // in seconds
    private boolean isPaused = false;
    
    // ===== Energy Monitoring =====
    private double totalKineticEnergy = 0;
    private double totalPotentialEnergy = 0;
    private double totalEnergy = 0;
    
    // ===== UI Components =====
    private JLabel timeLabel;
    private JLabel timeScaleLabel;
    private JLabel atlasStatusLabel;
    
    /**
     * Celestial Body Class with full 3D physics
     */
    public static class CelestialBody {
        // Position (meters)
        public double x, y, z;
        // Velocity (m/s)
        public double vx, vy, vz;
        // Physical properties
        public double mass; // kg
        public double radius; // meters
        public boolean movable = true;
        // Visualization
        public Color color;
        public String name;
        
        public CelestialBody(String name, double x, double y, double z, 
                           double vx, double vy, double vz, 
                           double mass, double radius, Color color) {
            this.name = name;
            this.x = x;
            this.y = y;
            this.z = z;
            this.vx = vx;
            this.vy = vy;
            this.vz = vz;
            this.mass = mass;
            this.radius = radius;
            this.color = color;
        }
        
        /**
         * Calculate kinetic energy: E_kin = 1/2 * m * v^2
         */
        public double getKineticEnergy() {
            double velocitySquared = vx*vx + vy*vy + vz*vz;
            return 0.5 * mass * velocitySquared;
        }
        
        /**
         * Calculate distance to another body
         */
        public double distanceTo(CelestialBody other) {
            double dx = other.x - x;
            double dy = other.y - y;
            double dz = other.z - z;
            return Math.sqrt(dx*dx + dy*dy + dz*dz);
        }
        
        @Override
        public String toString() {
            return String.format("%s: mass=%.2e kg, pos=(%.2e, %.2e) m, vel=(%.2e, %.2e) m/s", 
                name, mass, x/AU, y/AU, vx, vy);
        }
    }
    
    public GravitySimulationQwen() {
        setPreferredSize(new Dimension(FRAME_WIDTH, FRAME_HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);
        
        // Initialize with realistic solar system parameters
        initializeSolarSystem();
        
        // Setup simulation timer (60 FPS target)
        Timer timer = new Timer(16, this); // ~60 FPS
        timer.start();
        
        // Setup keyboard controls
        setupKeyboardControls();
        
        // Initialize last frame time
        lastFrameTime = System.currentTimeMillis();
    }
    
    /**
     * Initialize the solar system with scientifically accurate parameters
     */
    private void initializeSolarSystem() {
        bodies.clear();
        
        // ===== Sun =====
        CelestialBody sun = new CelestialBody("Sun", 0, 0, 0, 0, 0, 0, 
            1.0 * SOLAR_MASS, 6.9634e8, Color.YELLOW);
        
        // ===== Inner Planets (scaled for visualization) =====
        addPlanet("Mercury", sun, 0.387 * AU, 0.055 * EARTH_MASS, 4.88e6, 
                 new Color(150, 150, 150), true);
        addPlanet("Venus", sun, 0.723 * AU, 0.815 * EARTH_MASS, 6.05e6, 
                 new Color(200, 100, 0), false);
        addPlanet("Earth", sun, 1.0 * AU, 1.0 * EARTH_MASS, 6.37e6, 
                 Color.BLUE, true);
        addPlanet("Mars", sun, 1.524 * AU, 0.107 * EARTH_MASS, 3.39e6, 
                 Color.RED, false);
        
        // ===== Outer Planets =====
        addPlanet("Jupiter", sun, 5.203 * AU, 317.8 * EARTH_MASS, 6.99e7, 
                 new Color(200, 150, 100), true);
        addPlanet("Saturn", sun, 9.537 * AU, 95.2 * EARTH_MASS, 5.82e7, 
                 new Color(200, 200, 100), false);
        addPlanet("Uranus", sun, 19.191 * AU, 14.5 * EARTH_MASS, 2.54e7, 
                 new Color(150, 200, 250), true);
        addPlanet("Neptune", sun, 30.069 * AU, 17.1 * EARTH_MASS, 2.46e7, 
                 new Color(50, 50, 255), false);
        
        // ===== 3I/ATLAS - Scientifically accurate hyperbolic trajectory =====
        double atlasInitialDistance = 50 * AU;
        double approachAngle = Math.toRadians(30);
        
        double atlasX = atlasInitialDistance * Math.cos(approachAngle);
        double atlasY = atlasInitialDistance * Math.sin(approachAngle);
        
        double vInfinity = 58000; // m/s
        double velocityAngle = approachAngle + Math.PI/2;
        
        double atlasVx = vInfinity * Math.cos(velocityAngle);
        double atlasVy = vInfinity * Math.sin(velocityAngle);
        
        double atlasRadius = 500; // meters
        double atlasVolume = (4.0/3.0) * Math.PI * Math.pow(atlasRadius, 3);
        double atlasMass = atlasVolume * 1000;
        
        CelestialBody atlas = new CelestialBody("3I/ATLAS", atlasX, atlasY, 0, 
                                             atlasVx, atlasVy, 0, 
                                             atlasMass, atlasRadius * 1000, 
                                             new Color(50, 200, 255));
        
        System.out.println("3I/ATLAS initialized with scientific parameters:");
        System.out.println(atlas);
        
        bodies.add(sun);
        bodies.add(atlas);
    }
    
    /**
     * Add a planet with correct orbital velocity for circular orbit approximation
     */
    private void addPlanet(String name, CelestialBody sun, double distance, 
                          double mass, double radius, Color color, boolean clockwise) {
        double orbitalSpeed = Math.sqrt(GRAVITATIONAL_CONSTANT * sun.mass / distance);
        if (!clockwise) orbitalSpeed = -orbitalSpeed;
        
        CelestialBody planet = new CelestialBody(name, distance, 0, 0, 
                                              0, orbitalSpeed, 0, 
                                              mass, radius, color);
        bodies.add(planet);
    }
    
    /**
     * What-if scenario: Increase ATLAS mass to explore gravitational anomalies
     */
    public void increaseAtlasMass(double multiplier) {
        for (CelestialBody body : bodies) {
            if (body.name.equals("3I/ATLAS")) {
                double originalMass = body.mass;
                body.mass *= multiplier;
                System.out.printf("3I/ATLAS mass increased by factor %.0f: %.2e kg -> %.2e kg%n",
                    multiplier, originalMass, body.mass);
            }
        }
    }
    
    /**
     * Scientific N-body simulation using Velocity Verlet integration
     */
    private void simulateStep(double timeStep) {
        int n = bodies.size();
        double[][] accelerations = new double[n][3];
        
        // Calculate accelerations from all bodies
        for (int i = 0; i < n; i++) {
            CelestialBody body = bodies.get(i);
            if (!body.movable) continue;
            
            double ax = 0, ay = 0, az = 0;
            
            for (int j = 0; j < n; j++) {
                if (i == j) continue;
                CelestialBody other = bodies.get(j);
                
                double dx = other.x - body.x;
                double dy = other.y - body.y;
                double dz = other.z - body.z;
                double distance = Math.sqrt(dx*dx + dy*dy + dz*dz);
                
                if (distance < 1e6) distance = 1e6;
                
                double force = GRAVITATIONAL_CONSTANT * body.mass * other.mass / (distance * distance);
                double acceleration = force / body.mass;
                
                ax += acceleration * dx / distance;
                ay += acceleration * dy / distance;
                az += acceleration * dz / distance;
            }
            
            accelerations[i][0] = ax;
            accelerations[i][1] = ay;
            accelerations[i][2] = az;
        }
        
        // Update velocities and positions (Velocity Verlet)
        for (int i = 0; i < n; i++) {
            CelestialBody body = bodies.get(i);
            if (!body.movable) continue;
            
            body.vx += accelerations[i][0] * timeStep / 2.0;
            body.vy += accelerations[i][1] * timeStep / 2.0;
            body.vz += accelerations[i][2] * timeStep / 2.0;
            
            body.x += body.vx * timeStep;
            body.y += body.vy * timeStep;
            body.z += body.vz * timeStep;
        }
        
        // Recalculate accelerations for second half-step
        for (int i = 0; i < n; i++) {
            CelestialBody body = bodies.get(i);
            if (!body.movable) continue;
            
            double ax = 0, ay = 0, az = 0;
            
            for (int j = 0; j < n; j++) {
                if (i == j) continue;
                CelestialBody other = bodies.get(j);
                
                double dx = other.x - body.x;
                double dy = other.y - body.y;
                double dz = other.z - body.z;
                double distance = Math.sqrt(dx*dx + dy*dy + dz*dz);
                
                if (distance < 1e6) distance = 1e6;
                
                double force = GRAVITATIONAL_CONSTANT * body.mass * other.mass / (distance * distance);
                double acceleration = force / body.mass;
                
                ax += acceleration * dx / distance;
                ay += acceleration * dy / distance;
                az += acceleration * dz / distance;
            }
            
            body.vx += ax * timeStep / 2.0;
            body.vy += ay * timeStep / 2.0;
            body.vz += az * timeStep / 2.0;
        }
        
        // Update simulation time
        simulationTime += timeStep;
        
        // Monitor energy conservation
        monitorEnergyConservation();
    }
    
    private void monitorEnergyConservation() {
        totalKineticEnergy = 0;
        totalPotentialEnergy = 0;
        
        for (CelestialBody body : bodies) {
            totalKineticEnergy += body.getKineticEnergy();
        }
        
        for (int i = 0; i < bodies.size(); i++) {
            for (int j = i + 1; j < bodies.size(); j++) {
                CelestialBody a = bodies.get(i);
                CelestialBody b = bodies.get(j);
                double distance = a.distanceTo(b);
                totalPotentialEnergy -= GRAVITATIONAL_CONSTANT * a.mass * b.mass / distance;
            }
        }
        
        totalEnergy = totalKineticEnergy + totalPotentialEnergy;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (isPaused) {
            repaint();
            return;
        }
        
        long currentTime = System.currentTimeMillis();
        double deltaTime = (currentTime - lastFrameTime) / 1000.0; // seconds
        lastFrameTime = currentTime;
        
        // Apply time scale factor
        double simulationDeltaTime = deltaTime * timeScale;
        
        // Cap maximum time step to prevent instability
        simulationDeltaTime = Math.min(simulationDeltaTime, 86400); // max 1 day per frame
        
        // Accumulate time and process physics steps
        accumulatedTime += simulationDeltaTime;
        
        // Process multiple physics steps if needed (for stability at high time scales)
        while (accumulatedTime >= BASE_TIME_STEP) {
            simulateStep(timeScale);
            accumulatedTime -= timeScale;
        }
        
        repaint();
        updateStatusLabels();
    }
    
    private void updateStatusLabels() {
        if (timeLabel != null) {
            double years = simulationTime / EARTH_ORBITAL_PERIOD;
            timeLabel.setText(String.format("Simulation Time: %.2f years", years));
        }
        
        if (timeScaleLabel != null) {
            if (timeScale == 1.0) {
                timeScaleLabel.setText("Time Scale: REAL-TIME (1:1)");
            } else if (timeScale < 1.0) {
                timeScaleLabel.setText(String.format("Time Scale: %.2e× SLOWER", 1.0/timeScale));
            } else {
                timeScaleLabel.setText(String.format("Time Scale: %.2e× FASTER", timeScale));
            }
        }
        
        if (atlasStatusLabel != null) {
            for (CelestialBody body : bodies) {
                if (body.name.equals("3I/ATLAS")) {
                    double distanceToSun = Math.sqrt(body.x*body.x + body.y*body.y) / AU;
                    atlasStatusLabel.setText(String.format("3I/ATLAS: %.2f AU from Sun", distanceToSun));
                }
            }
        }
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw background stars
        drawStars(g2d);
        
        // Draw celestial bodies
        for (CelestialBody body : bodies) {
            drawCelestialBody(g2d, body);
        }
        
        // Draw trajectory of 3I/ATLAS
        drawAtlasTrajectory(g2d);
        
        // Draw UI information
        drawInfoOverlay(g2d);
    }
    
    private void drawCelestialBody(Graphics2D g2d, CelestialBody body) {
        // Calculate scale factor for visualization (not physical scale)
        double visualizationScale = 1e6; // Scale down for visibility
        
        double screenX = (zoomCenterX + body.x / AU) * zoomFactor + getWidth() / 2.0;
        double screenY = (zoomCenterY + body.y / AU) * zoomFactor + getHeight() / 2.0;
        
        // Calculate visible radius (scaled for visibility)
        double radiusScale = 1e4; // For visualization only
        double visibleRadius = Math.max(body.radius / AU * zoomFactor * radiusScale, MIN_RADIUS_DRAW);
        visibleRadius = Math.min(visibleRadius, 50); // Cap maximum size
        
        g2d.setColor(body.color);
        g2d.fillOval((int)(screenX - visibleRadius), (int)(screenY - visibleRadius), 
                    (int)(visibleRadius * 2), (int)(visibleRadius * 2));
        
        // Draw name label for major bodies
        if (body.mass > 0.01 * EARTH_MASS || body.name.equals("3I/ATLAS")) {
            g2d.setColor(Color.WHITE);
            g2d.drawString(body.name, (int)(screenX + visibleRadius + 5), (int)(screenY));
        }
    }
    
    private void drawStars(Graphics2D g2d) {
        g2d.setColor(new Color(50, 50, 80));
        for (int i = 0; i < 200; i++) {
            int x = random.nextInt(getWidth());
            int y = random.nextInt(getHeight());
            int size = random.nextInt(2) + 1;
            g2d.fillOval(x, y, size, size);
        }
    }
    
    private void drawAtlasTrajectory(Graphics2D g2d) {
        g2d.setColor(new Color(100, 200, 255, 150));
        g2d.setStroke(new BasicStroke(2.0f));
        
        for (CelestialBody body : bodies) {
            if (body.name.equals("3I/ATLAS")) {
                double predictionSteps = 100;
                double stepSize = 86400; // 1 day in seconds
                
                double currentX = body.x;
                double currentY = body.y;
                double currentVX = body.vx;
                double currentVY = body.vy;
                
                for (int i = 0; i < predictionSteps; i++) {
                    double screenX = (zoomCenterX + currentX / AU) * zoomFactor + getWidth() / 2.0;
                    double screenY = (zoomCenterY + currentY / AU) * zoomFactor + getHeight() / 2.0;
                    
                    // Simple Euler integration for visualization only
                    currentX += currentVX * stepSize;
                    currentY += currentVY * stepSize;
                    
                    double nextScreenX = (zoomCenterX + currentX / AU) * zoomFactor + getWidth() / 2.0;
                    double nextScreenY = (zoomCenterY + currentY / AU) * zoomFactor + getHeight() / 2.0;
                    
                    g2d.drawLine((int)screenX, (int)screenY, (int)nextScreenX, (int)nextScreenY);
                }
                break;
            }
        }
    }
    
    private void drawInfoOverlay(Graphics2D g2d) {
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Title and vision statement
        g2d.drawString("N-Body Gravitation Simulation - Time Control Enhanced", 20, 30);
        
        // Controls info (updated with time controls)
        g2d.setFont(new Font("Arial", Font.PLAIN, 12));
        g2d.drawString("Navigation: Arrow Keys = Pan, + / - = Zoom, Space = Reset View", 20, getHeight() - 60);
        g2d.drawString("Time Control: > = Faster (×2), < = Slower (÷2), P = Pause/Resume", 20, getHeight() - 40);
        g2d.drawString("Mass Control: M = Increase 3I/ATLAS mass (scientific exploration)", 20, getHeight() - 20);
    }
    
    private void setupKeyboardControls() {
        // Grundlegende Navigation
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("UP"), "panUp");
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("DOWN"), "panDown");
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("LEFT"), "panLeft");
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("RIGHT"), "panRight");
        
        // ZOOM - Korrigiert für deutsche Tastaturen
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("PLUS"), "zoomIn");           // Haupt-Tastatur +
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("ADD"), "zoomIn");            // Ziffernblock +
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("EQUALS"), "zoomIn");         // Alternative
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("MINUS"), "zoomOut");         // Haupt-Tastatur -
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("SUBTRACT"), "zoomOut");      // Ziffernblock -
        
        // ZEITSTEUERUNG - Neu und exponentiell
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("D"), "timeFaster");     // ">" Taste
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("A"), "timeSlower");      // "<" Taste
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("P"), "pauseToggle");
        
        // Hilfsfunktionen
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("SPACE"), "resetView");
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("M"), "massIncrease");
        getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke("ESCAPE"), "escape");
        
        // ActionMap
        getActionMap().put("panUp", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { panUp(); }
        });
        getActionMap().put("panDown", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { panDown(); }
        });
        getActionMap().put("panLeft", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { panLeft(); }
        });
        getActionMap().put("panRight", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { panRight(); }
        });
        getActionMap().put("zoomIn", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { zoomIn(); }
        });
        getActionMap().put("zoomOut", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { zoomOut(); }
        });
        getActionMap().put("resetView", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { resetView(); }
        });
        getActionMap().put("massIncrease", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { increaseAtlasMass(1000.0); }
        });
        getActionMap().put("timeFaster", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { increaseTimeScale(); }
        });
        getActionMap().put("timeSlower", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { decreaseTimeScale(); }
        });
        getActionMap().put("pauseToggle", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { togglePause(); }
        });
        getActionMap().put("escape", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { requestFocusInWindow(); }
        });
    }
    
    // ===== Time Control Methods =====
    private void increaseTimeScale() {
        timeScale = timeScale * TIME_SCALE_STEP;
        System.out.println("Time scale increased: " + timeScale);
    }
    
    private void decreaseTimeScale() {
        timeScale = timeScale / TIME_SCALE_STEP;
        System.out.println("Time scale decreased: " + timeScale);
    }
    
    private void togglePause() {
        isPaused = !isPaused;
        System.out.println("Simulation " + (isPaused ? "PAUSED" : "RESUMED"));
    }
    
    // ===== Navigation Methods =====
    public void panLeft() { zoomCenterX += PAN_STEP_BASE / AU / zoomFactor; repaint(); }
    public void panRight() { zoomCenterX -= PAN_STEP_BASE / AU / zoomFactor; repaint(); }
    public void panUp() { zoomCenterY += PAN_STEP_BASE / AU / zoomFactor; repaint(); }
    public void panDown() { zoomCenterY -= PAN_STEP_BASE / AU / zoomFactor; repaint(); }
    public void zoomIn() { zoomFactor *= ZOOM_STEP; repaint(); }
    public void zoomOut() { zoomFactor /= ZOOM_STEP; repaint(); }
    public void resetView() { zoomFactor = 1.0; zoomCenterX = 0; zoomCenterY = 0; repaint(); }
    
    // ===== Main Application =====
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Advanced Gravitation Simulation - Time Control Edition");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            GravitySimulationQwen simulation = new GravitySimulationQwen();
            
            // Create control panel
            JPanel controlPanel = new JPanel();
            controlPanel.setBackground(new Color(20, 20, 40));
            controlPanel.setForeground(Color.WHITE);
            
            
            
            // Style the labels
            Font labelFont = new Font("Arial", Font.BOLD, 14);
          
            
            // Add mass increase buttons for scientific exploration
            JButton smallMassIncrease = new JButton("Increase Atlas Mass 10x");
            JButton largeMassIncrease = new JButton("Increase Atlas Mass 1000x");
            
            smallMassIncrease.addActionListener(e -> simulation.increaseAtlasMass(10.0));
            largeMassIncrease.addActionListener(e -> simulation.increaseAtlasMass(1000.0));
            
            controlPanel.add(smallMassIncrease);
            controlPanel.add(largeMassIncrease);
            
            frame.setLayout(new BorderLayout());
            frame.add(simulation, BorderLayout.CENTER);
            frame.add(controlPanel, BorderLayout.SOUTH);
            
            frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            simulation.requestFocusInWindow();
            
            // Display scientific context with time control info
            JOptionPane.showMessageDialog(frame,
                "🌟 Scientific Time Control System 🌟\n\n" +
                "This simulation starts in REAL-TIME mode:\n" +
                "• 1 simulation second = 1 real second\n" +
                "• Earth takes 1 real year to complete one orbit\n\n" +
                "⏱️ Time Control:\n" +
                "• Press '>' to double the speed (exponential acceleration)\n" +
                "• Press '<' to halve the speed (exponential deceleration)\n" +
                "• Press 'P' to pause/resume\n\n" +
                "🚀 Practical Usage:\n" +
                "1. Start in real-time to observe natural motion\n" +
                "2. Press '>' repeatedly to speed up and see 3I/ATLAS trajectory\n" +
                "3. Press '<' to slow down when interesting events occur\n" +
                "4. Use 'M' to explore extreme mass scenarios scientifically\n\n" +
                "💡 Note: Time scale ranges from 1 microsecond to 31 years per real second!",
                "Time Control Guide", JOptionPane.INFORMATION_MESSAGE);
        });
    }
}