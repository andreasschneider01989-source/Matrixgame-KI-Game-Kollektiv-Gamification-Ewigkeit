package p1;

import java.awt.Color;

public class photon extends MasseKugel{
	
	// Das Photon ist genau dann Messbar wenn es mit c beim Beobachter oder Messer eintrifft - Analogie zu Schallwellen
	double frequenz;
	double wellenlänge;
	double energie;
	
	double plankfrequenz = 1.855*Math.pow(10, 43); // in s^-1 bzw. Hz
	double plankWellenlänge = 1.616* Math.pow(10,-35); // in meter(m) //untereinheit bzw. Schritt bei Wellenlängen von Licht
	
	double plankKonstante = 6.62607015*Math.pow(10, -34); //J\cdotps
	double plankEnergie= 1.986*Math.pow(10, -25)/plankWellenlänge; //Plankenergie in Joul
	double lichtgeschwindigkeit = 299792458; // Lichtgeschwindigkeit in m/s
	
	// E=m*c*c   //oder E=0.5*m*c*c-> m=2*E/c/c
	// m=E/c/c
	double plankMasse1 = plankEnergie/lichtgeschwindigkeit/lichtgeschwindigkeit; //Plankmasse in kg
	double plankMasse2 = plankMasse1*2;  // Plankmasse2 in kg
	
	// E=h*f=6.62607015*Math.pow(10, -34)*1.855*Math.pow(10, 43);
	// Da wird leider keine minimale Einheit definiert mit der sich rechnen lässt
	
	
	

	public photon(double x, double y, double z, double vx, double vy, double vz, double mass, int radius, Color color) {
		super(x, y, z, vx, vy, vz, mass, radius, color);
		// TODO Auto-generated constructor stub
	}
	
	// Weitere Konstruktoren mit Energie, Wellenlänge und Frequenz

}
