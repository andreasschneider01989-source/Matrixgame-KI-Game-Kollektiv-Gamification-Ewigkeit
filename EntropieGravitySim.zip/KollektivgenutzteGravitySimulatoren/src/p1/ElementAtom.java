package p1;

import java.awt.Color;

public class ElementAtom extends MasseKugel{
	String Artikel = "--"; // ".."=Elektrische Litfähigkeit=Metall=MetallischerGlanz
	String protonenzahl; // Ordunungszahl binärcodiert und in Luminiziffern-=1, .=0
	String valenzelektronen; // Elektronen in der äußersten Hülle binärcodiert und in Luminiziffern-=1, .=0
	String dichte; // Vielfaches der Dichte von H2O in Lumini
	
	int ordnungszahl;
	int neutronenZahl;
	String name;
	String symbol;
	double atomgewicht;
	double dichteDouble;
	String serie;
	double elektronegativitätDouble;
	double potentielleChemischeEnergie;
	double halbwärtszeit;
	Color rgbWerte;
	double elektrischeLeitfähigkeit;
	int[] orbitalBefüllungen;
	double häufigkeitUniversum;
	double häufigkeitSonnensystem;
	double häufigkeitErde;
	double häufigketErdoberfläche;
	
	double protonenMasse = 1.6726*Math.pow(10, -27);
	double protonenMasseu = 1.00728;
	double protonenMasseElektronen= 1836.166666;
	
	double neutronenMasse = 1.6749*Math.pow(10, -27);
	double neutronenMasseu= 1.00866;
	double neutronenMasseElektronen=1838.6666666;
	
	double elektronenMasse=9.1094*Math.pow(10, -31);
	double elektronenMasseu= 0.00054858;
	
	


	
	
	// Lumini Konstruktor, setzt die ganzen Werte noch nicht
	public ElementAtom(String artikel, String protonenzahl, String valenzelektronen) {
		super(0,0,0,0,0,0,1,5,new Color(255,0,0)); //double x, double y, double z, double vx, double vy, double vz, double mass, int radius, Color color
		this.Artikel=artikel;
		this.protonenzahl=protonenzahl;
		this.valenzelektronen=valenzelektronen;
	}
	
	// Isotopkonstruktor
	public ElementAtom(int protonenzahl, int neutronenzahl) {
		super(0,0,0,0,0,0,1,5,new Color(255,0,0)); //double x, double y, double z, double vx, double vy, double vz, double mass, int radius, Color color
	}
	
}
