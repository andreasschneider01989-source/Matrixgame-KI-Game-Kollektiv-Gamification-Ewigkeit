package p1;

import java.awt.Color;

public class Sonne extends MasseKugel{
	
	double oberflächentemperatur;
	String typ;


	public Sonne(double x, double y, double z, double vx, double vy, double vz, double mass, int radius, Color color
			) {
		super(x, y, z, vx, vy, vz, mass, radius, color);
		// TODO Auto-generated constructor stub
	}

}
