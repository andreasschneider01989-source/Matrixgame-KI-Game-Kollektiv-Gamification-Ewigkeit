package lumini; // Ein neues, eigenes Paket für den Prototyp

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * MatrixGamePrototype: Kombiniert LuminiPixelEncoder (Steuerung) und Gravity Sim (main2) 
 * in einer einzigen, schnell testbaren Klasse.
 */
public class MatrixGamePrototype extends JFrame {

    // --- 1. Simulations- und GUI-Konstanten ---
    private final int MATRIX_COLUMNS = 50; 
    private final double G = 0.01;
    private double timeStep = 0.005; 
    
    // --- 2. Datenstrukturen ---
    private final Map<Character, Color> luminiMap;
    private final List<MasseKugel> bodies = new ArrayList<>();
    
    // --- 3. GUI-Elemente und Status ---
    private final JTextField inputField;
    private final JTextArea infoArea;
    private final JTextField massInputField;
    private final PixelCanvas pixelCanvas;
    private int selectedObjectIndex = -1; // Aktuell ausgewählter Index

    // =================================================================================
    // START: HILFSKLASSE MASSEKUGEL (Für den Prototyp hier definiert)
    // =================================================================================
    public class MasseKugel {
        double x, y, z;
        double vx, vy, vz;
        double mass;
        int radius;
        Color color;
        
        // Metadaten für die Verknüpfung mit dem Lumini-Encoder
        char luminiChar = ' ';

        public MasseKugel(double x, double y, double z, double vx, double vy, double vz, double mass, int radius, Color color) {
            this.x = x; this.y = y; this.z = z;
            this.vx = vx; this.vy = vy; this.vz = vz;
            this.mass = mass;
            this.radius = radius;
            this.color = color;
        }

        // Simuliert Gravitationsbeschleunigung durch ein anderes Objekt (Simplified)
        public void applyGravity(MasseKugel other, double dt) {
            if (this == other || this.mass == 0 || other.mass == 0) return;

            double dx = other.x - this.x;
            double dy = other.y - this.y;
            double dz = other.z - this.z;
            double r2 = dx * dx + dy * dy + dz * dz;
            double r = Math.sqrt(r2);
            
            // Vermeidet Division durch Null/zu kleine Werte
            if (r < 0.1) r = 0.1; 

            double F = G * this.mass * other.mass / (r * r);
            double ax = F * dx / r / this.mass;
            double ay = F * dy / r / this.mass;
            // dz wird hier ignoriert, da wir nur in 2D zeichnen, aber es wäre Teil der 3D-Sim

            this.vx += ax * dt;
            this.vy += ay * dt;
        }

        // Aktualisiert die Position
        public void updatePosition(double dt) {
            this.x += this.vx * dt;
            this.y += this.vy * dt;
        }
    }
    // =================================================================================
    // ENDE: HILFSKLASSE MASSEKUGEL
    // =================================================================================

    // --- Konstruktor ---
    public MatrixGamePrototype() {
        luminiMap = createLuminiMap();
        initBodies(30); // Initialisiere 30 Massenkugeln

        // Fenstereinstellungen
        setTitle("Matrixgame 3D Universum - Prototyp (Lumini Steuerung)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 700);
        setLayout(new BorderLayout(10, 10));

        // --- 3. Steuerung und Eingabe (Nord-Panel) ---
        JPanel topPanel = new JPanel(new BorderLayout());
        inputField = new JTextField("0123456789abcdefghijklmnopqrstuvwxyz"); // Startwert
        inputField.setFont(new Font("Monospaced", Font.PLAIN, 16));
        
        // Listener für Echtzeit-Kodierung
        inputField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { updatePixelView(); }
            public void removeUpdate(DocumentEvent e) { updatePixelView(); }
            public void changedUpdate(DocumentEvent e) { /* Not used */ }
        });
        topPanel.add(inputField, BorderLayout.CENTER);

        // Slider für die PIXEL_SIZE (Zoom)
        JSlider sizeSlider = new JSlider(JSlider.HORIZONTAL, 5, 50, 10); 
        sizeSlider.setPaintTicks(true);
        sizeSlider.setPaintLabels(true);
        
        JPanel sliderPanel = new JPanel(new BorderLayout());
        sliderPanel.add(new JLabel("Pixel Größe (Zoom):"), BorderLayout.WEST);
        sliderPanel.add(sizeSlider, BorderLayout.CENTER);
        topPanel.add(sliderPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // --- 4. Steuerungs-Bereich (Ost-Panel) ---
        JPanel eastPanel = new JPanel();
        eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.Y_AXIS));
        
        infoArea = new JTextArea("Klicken Sie auf ein Pixel, um die Daten der MasseKugel anzuzeigen.");
        infoArea.setEditable(false);
        infoArea.setPreferredSize(new Dimension(250, 200)); 
        eastPanel.add(new JScrollPane(infoArea));

        massInputField = new JTextField();
        massInputField.setFont(new Font("Monospaced", Font.BOLD, 14));
        
        eastPanel.add(new JLabel("--- Steuerung: Masse (Eingabe + ENTER) ---"));
        eastPanel.add(massInputField);
        add(eastPanel, BorderLayout.EAST);

        // --- 5. Pixel-Zeichenfläche (Zentrum) ---
        pixelCanvas = new PixelCanvas(); 
        sizeSlider.addChangeListener(e -> { 
            pixelCanvas.setPixelSize(sizeSlider.getValue());
            pixelCanvas.repaint();
        });
        add(new JScrollPane(pixelCanvas), BorderLayout.CENTER);

        // --- 6. ActionListener für Masse-Steuerung ---
        massInputField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedObjectIndex != -1) {
                    try {
                        double newMass = Double.parseDouble(massInputField.getText());
                        updateMassOfSelectedObject(newMass); 
                        massInputField.setText("");
                    } catch (NumberFormatException ex) {
                        infoArea.append("\n!! Fehler: Ungültige Zahleneingabe für Masse.");
                        massInputField.setText("");
                    }
                } else {
                    infoArea.setText("Bitte zuerst ein Pixel anklicken.");
                }
            }
        });
        
        // --- 7. Simulations-Timer starten ---
        Timer simTimer = new Timer(10, this::runSimulationStep); // 10ms (100 FPS)
        simTimer.start();
        
        // Initialisieren der Ansicht
        updatePixelView(); 
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    // --- Massen-Änderungslogik (Wird von der Steuerung aufgerufen) ---
    public void updateMassOfSelectedObject(double newMass) {
        if (selectedObjectIndex >= 0 && selectedObjectIndex < bodies.size()) {
            MasseKugel body = bodies.get(selectedObjectIndex);
            body.mass = newMass;
            
            // Optionale visuelle Rückkopplung: Farbe basierend auf Masse ändern
            int brightness = (int) Math.min(255, 100 + newMass * 5); // Hellere Kugel bei mehr Masse
            body.color = new Color(brightness, 0, 255 - brightness/2);
            
            infoArea.append(String.format("\n>> Masse des Index %d auf %.2f geändert. (Sim und PSE aktualisiert)\n", selectedObjectIndex, newMass));
            
            // Aktualisiere Canvas und Sim-Ansicht
            pixelCanvas.repaint(); 
            // Die Simulation läuft bereits über den Timer weiter
        }
    }
    
    // --- Simulations-Logik (Ersetzt die actionPerformed-Methode in main2) ---
    private void runSimulationStep(ActionEvent e) {
        // 1. Berechnung der Gravitationskräfte (N-Körper-Problem)
        for (MasseKugel b1 : bodies) {
            for (MasseKugel b2 : bodies) {
                b1.applyGravity(b2, timeStep);
            }
        }
        
        // 2. Aktualisierung der Positionen
        for (MasseKugel body : bodies) {
            body.updatePosition(timeStep);
        }
        
        // 3. Neuzeichnen
        pixelCanvas.repaint();
    }

    // --- Methoden zum Erstellen von Massenkugeln (Analog zu main2.initBodies) ---
    private void initBodies(int number) {
        Random rnd = new Random();
        double size = 50.0;
        
        // Zentrumskugel (Sonne / Kern)
        bodies.add(new MasseKugel(0, 0, 0, 0, 0, 0, 3000.0, 10, Color.YELLOW));
        
        // Zufällige 'Planeten'
        for (int i = 1; i < number; i++) {
            // Position
            double x = rnd.nextDouble() * 2 * size - size;
            double y = rnd.nextDouble() * 2 * size - size;
            double r = Math.sqrt(x*x + y*y);
            
            // Masse
            double mass = rnd.nextDouble() * 10 + 1; // 1 bis 11
            
            // Geschwindigkeit (Für stabile Orbitale um das Zentrum 0,0)
            double requiredSpeed = Math.sqrt(G * bodies.get(0).mass / r); 
            double vx = -y / r * requiredSpeed * (rnd.nextDouble() * 0.5 + 0.75);
            double vy = x / r * requiredSpeed * (rnd.nextDouble() * 0.5 + 0.75);

            MasseKugel mk = new MasseKugel(x, y, 0, vx, vy, 0, mass, 4, Color.BLUE);
            bodies.add(mk);
        }
    }

    // --- Lumini-Zuordnung (Analog zu LuminiPixelEncoder.createLuminiMap) ---
    private Map<Character, Color> createLuminiMap() {
        Map<Character, Color> map = new HashMap<>();
        // Kern-Lumini-Kodierung
        map.put('0', new Color(0,0,0)); map.put('1', new Color(0,0,255)); map.put('2', new Color(0,255,0));    
        map.put('3', new Color(0,255,255)); map.put('4', new Color(255,0,0)); map.put('5', new Color(255,0,255));       
        map.put('6', new Color(255,255,0)); map.put('7', new Color(255,255,255)); map.put('8', new Color(0,0,128));       
        map.put('9', new Color(0,128,255)); map.put('a', new Color(0,255,128)); map.put('b', new Color(0,128,255));       
        map.put('c', new Color(255,0,128)); map.put('d', new Color(255,128,255)); map.put('e', new Color(255,255,128));       
        map.put('f', new Color(255,128,255)); map.put('g', new Color(128,0,0)); map.put('h', new Color(0,0,128));      
        map.put('i', new Color(128,255,0)); map.put('j', new Color(0,255,128)); map.put('k', new Color(255,128,0));      
        map.put('l', new Color(128,0,255)); map.put('m', new Color(255,255,128)); map.put('n', new Color(128,255,255));       
        map.put('o', new Color(128,0,128)); map.put('p', new Color(0,128,128)); map.put('q', new Color(0,255,0));    
        map.put('r', new Color(0,255,255)); map.put('s', new Color(255,0,0)); map.put('t', new Color(255,0,255));       
        map.put('u', new Color(255,255,0)); map.put('v', new Color(255,255,255)); map.put('w', new Color(128,128,128));       
        map.put('x', new Color(0,128,255)); map.put('y', new Color(0,128,128)); map.put('z', new Color(64,128,128));       
        map.put(' ', new Color(6, 30, 210)); 
        return map;
    }

    // --- Aktualisierung der Lumini-Ansicht (Analog zu LuminiPixelEncoder.updatePixelView) ---
    private void updatePixelView() {
        String text = inputField.getText();
        
        // Die Lumini-Zeichen des Texts werden auf die ersten N bodies angewendet
        int numBodies = bodies.size();
        for (int i = 0; i < numBodies; i++) {
            MasseKugel body = bodies.get(i);
            if (i < text.length()) {
                char c = text.charAt(i);
                body.luminiChar = c;
            } else {
                body.luminiChar = ' '; // Leerzeichen für nicht-kodierte Objekte
            }
        }
        
        pixelCanvas.repaint();
    }

    // =================================================================================
    // START: INNERE KLASSE PIXELCANVAS (Zeichnet PSE und Sim-Ansicht)
    // =================================================================================
    private class PixelCanvas extends JPanel {
        
        private int PIXEL_SIZE = 10; 
        private final int RGB_FONT_SIZE = 8;
        private final int CHAR_FONT_SIZE = 14; 
        
        // Sim-Zeichnungs-Parameter
        private final double SCALE = 5.0; // Zoom für die Sim-Ansicht (Werte im 100er Bereich auf 500er Bereich)
        private final int OFFSET_X = 500;
        private final int OFFSET_Y = 500;

        public PixelCanvas() {
            // MouseListener für die Steuerung der PSE-Ansicht
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    handlePixelClick(e.getX(), e.getY());
                }
            });
        }
        
        public void setPixelSize(int size) {
            this.PIXEL_SIZE = size;
        }
        
        private String generateInfoText(int index, MasseKugel data) {
             return String.format(
                "--- Geklicktes Lumini Objekt ---\n" +
                "Index: %d\n" +
                "Zeichen: '%c'\n" +
                "Masse: %.2f\n" +
                "Pos(x,y): (%.1f, %.1f)\n" +
                "Geschw(vx,vy): (%.2f, %.2f)\n" +
                "Lumini-Farbe: RGB(%d,%d,%d)",
                index,
                data.luminiChar,
                data.mass,
                data.x, data.y,
                data.vx, data.vy,
                luminiMap.getOrDefault(data.luminiChar, Color.ORANGE).getRed(),
                luminiMap.getOrDefault(data.luminiChar, Color.ORANGE).getGreen(),
                luminiMap.getOrDefault(data.luminiChar, Color.ORANGE).getBlue()
            );
        }

        private void handlePixelClick(int clickX, int clickY) {
            // Berechne Index aus den Klick-Koordinaten
            int col = clickX / PIXEL_SIZE;
            int row = clickY / PIXEL_SIZE;
            int index = row * MATRIX_COLUMNS + col;
            
            if (index >= 0 && index < bodies.size()) {
                selectedObjectIndex = index; 
                MasseKugel data = bodies.get(index);
                
                // 1. Informationen im InfoArea anzeigen
                infoArea.setText(generateInfoText(index, data));
                
                // 2. Masse in das Steuerfeld übernehmen
                massInputField.setText(String.format("%.2f", data.mass)); 

            } else {
                 selectedObjectIndex = -1;
                 infoArea.setText("Klicken Sie auf ein gültiges Pixel (innerhalb der Textlänge).");
                 massInputField.setText("");
            }
            repaint(); // Selektionsrahmen neu zeichnen
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            
            // --- 1. PSE-Ansicht (oben links) ---
            drawLuminiPixelView(g2d);
            
            // --- 2. Gravity-Sim-Ansicht (rechts oder unten rechts) ---
            drawGravitySimView(g2d);
        }
        
        private void drawLuminiPixelView(Graphics2D g2d) {
            for (int i = 0; i < bodies.size(); i++) {
                MasseKugel currentBody = bodies.get(i);
                
                // Stellt sicher, dass das Zeichen existiert
                if (currentBody.luminiChar == ' ') continue; 
                
                // Logik für die Matrix-Position
                int x = (i % MATRIX_COLUMNS) * PIXEL_SIZE;
                int y = (i / MATRIX_COLUMNS) * PIXEL_SIZE;
                
                Color currentColor = luminiMap.getOrDefault(currentBody.luminiChar, Color.ORANGE);
                
                // 1. Zeichne das Pixel-Quadrat
                g2d.setColor(currentColor);
                g2d.fillRect(x, y, PIXEL_SIZE, PIXEL_SIZE);

                // 2. Selektionsrahmen zeichnen
                if (i == selectedObjectIndex) {
                    g2d.setColor(Color.RED); 
                    g2d.setStroke(new BasicStroke(2)); 
                    g2d.drawRect(x, y, PIXEL_SIZE, PIXEL_SIZE);
                    g2d.setStroke(new BasicStroke(1)); 
                }

                // 3. Inhalte anzeigen, WENN PIXEL_SIZE >= 30
                if (PIXEL_SIZE >= 30) {
                    // (Ihre Logik zum Anzeigen von Zeichen und RGB-Werten)
                    double luminance = (0.2126 * currentColor.getRed() + 0.7152 * currentColor.getGreen() + 0.0722 * currentColor.getBlue()) / 255.0;
                    Color textColor = (luminance < 0.5) ? Color.WHITE : Color.BLACK;
                    g2d.setColor(textColor);
                    
                    g2d.setFont(new Font("Monospaced", Font.BOLD, CHAR_FONT_SIZE));
                    String charStr = String.valueOf(currentBody.luminiChar);
                    FontMetrics fm = g2d.getFontMetrics();
                    int charWidth = fm.stringWidth(charStr);
                    int charX = x + (PIXEL_SIZE - charWidth) / 2;
                    int charY = y + CHAR_FONT_SIZE + 2; 
                    g2d.drawString(charStr, charX, charY);
                }
            }
        }
        
        private void drawGravitySimView(Graphics2D g2d) {
            // Das Zentrum des Simulators
            g2d.setColor(Color.DARK_GRAY);
            g2d.drawOval(OFFSET_X - 100, OFFSET_Y - 100, 200, 200);
            
            g2d.translate(OFFSET_X, OFFSET_Y); // Ursprung in die Mitte verschieben

            for (MasseKugel body : bodies) {
                // Skalierung und Projektion der Sim-Koordinaten
                int sx = (int) (body.x * SCALE);
                int sy = (int) (body.y * SCALE);
                int r = body.radius; // Radius der Kugel

                // Hervorhebung: Wenn das Sim-Objekt dem selektierten Lumini-Pixel entspricht
                if (bodies.indexOf(body) == selectedObjectIndex) {
                    // Zeichne einen dicken, roten Rand im Sim
                    g2d.setColor(Color.RED);
                    g2d.drawOval(sx - r - 2, sy - r - 2, r * 2 + 4, r * 2 + 4); 
                }
                
                // Zeichne die MasseKugel selbst mit ihrer aktuellen Farbe
                // Wir verwenden die Farbe, die wir in updateMassOfSelectedObject() gesetzt haben
                g2d.setColor(body.color); 
                g2d.fillOval(sx - r, sy - r, r * 2, r * 2);
            }
            
            g2d.translate(-OFFSET_X, -OFFSET_Y); // Ursprung zurück verschieben
        }
    }
    // =================================================================================
    // ENDE: INNERE KLASSE PIXELCANVAS
    // =================================================================================

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MatrixGamePrototype::new);
    }
}